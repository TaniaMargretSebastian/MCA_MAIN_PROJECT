
<?php
        $apiKey="rzp_test_UcrXLCpAq1wu1o";
        include 'connection.php';
        session_start();
        $uid=$_SESSION['id'];
        if($_SESSION['id']==""){
            header('location:login.php');
          }
        $sqlii="SELECT register.loginid,register.fname,register.phone,register.adress,register.email,order_tbl.userid,order_tbl.id,order_tbl.cartid,order_tbl.price from order_tbl join register on register.loginid=order_tbl.userid where register.loginid='$uid'";
        $result = mysqli_query($con, $sqlii);
        $sr="SELECT price FROM order_tbl where order_tbl.userid='$uid'";
        $tt=mysqli_query($con,$sr);
        while ($row = mysqli_fetch_assoc($result)) {
            $id= $row['id'];
            $name=$row['fname'];
            $email=$row['email'];
            $phone=$row['phone'];
            $cc=$row['cartid'];

        }
        $sql=mysqli_query($con,"SELECT price from order_tbl where userid='$uid'");
        while($er=mysqli_fetch_array($sql)){
            $amounts=$er['price'];
        }
       
?>

<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>.</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="csss/css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="csss/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="csss/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="csss/css/custom.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
              
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                
                
                   
                  
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt=""  style="height: 124px;width: 147px;"></a>
                    <div class="brand_name">
                    <h2 style="margin-top: 10px;font-family: 'Montserrat';font-weight: 600;">MountainFresh<br>Products<h2>
                    
                    </div>

                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                       <!-- <li class="nav-item"><a class="nav-link" href="index.php">HOME</a></li>-->
                        <li class="nav-item active"><a class="nav-link" href="shop.php?pid=1" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Shop</a></li>
                       
                        <li class="nav-item"><a class="nav-link" href="my-account.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Account</a></li>
                        <li class="nav-item"><a class="nav-link" href="orderview.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Order</a></li>
						<li class="nav-item"><a class="nav-link" href="cart.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Cart</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="logout.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Logout</a></li>
                    </ul>
                    <div class="w3l_header_right">
		
		<form class="example" action="search.php" method="POST">
        <input type="text" placeholder="Search.." name="search" >
        <button type="submit"><i class="fa fa-search" ></i></button>
        </form>
				
		
		</div>
                </div>
    </div>
    </header>
    
<form action="payment_action.php?bid=<?php echo $id ?>&&id=<?php echo $amounts ?>&&uu=<?php echo $cc ?>" method="POST">
<script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $apiKey; ?>" // Enter the Test API Key ID generated from Dashboard → Settings → API Keys
    data-amount="<?php echo $amounts * 100; ?>" // Amount is in currency subunits. Hence, 29935 refers to 29935 paise or ₹299.35.
    data-currency="INR"// You can accept international payments by changing the currency code. Contact our Support Team to enable International for your account
    data-order_id="<?php rand(100000, 999999);?>"// Replace with the order_id generated by you in the backend.
    data-buttontext="Pay"
    data-name="Mountain Fresh Products"
    data-description="Add more colors to your day"
    data-image=""
    data-prefill.name="<?php echo $name;?>"
    data-prefill.email="<?php echo $email;?>"
    data-prefill.contact="<?php echo $phone;?>"
    data-theme.color="#F37254"
></script>
<input type="hidden" custom="Hidden Element" name="hidden">
</form>
    </body>
<!--style>
.razorpay-payment-button { display:none; }
</style>


<script type="text/javascript">
  $(document).ready(function(){
    $('.razorpay-payment-button').click();

});
</script-->
</html>
<!-- <?php
header('location:../login.php');
?> -->
