<?php
session_start();
error_reporting(0);
include('connection.php');
if(strlen($_SESSION['logged_in'])==0)
    {   
header('location:login.php');
}
$cartid = $_GET['cid'];

$result=mysqli_query($con,"SELECT register.loginid, register.fname, register.phone, register.adress, order_tbl.pname, order_tbl.qty, order_tbl.price, order_tbl.date FROM register LEFT JOIN order_tbl ON register.loginid = order_tbl.userid where cartid='$cartid'") or die(mysqli_error($con));


include('pdf_mc_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'Bill ', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Cell(0,12,'Name : '. $row['fname'],0,1);
//$pdf->Cell(0,12,'Phone : '. $row['phone'],0,1);
// $pdf->Cell(0,12,'Gender : '. $row['gender'],0,1);
// $pdf->Cell(0,12,'Parent Name : '. $row['parent_name'],0,1);
// $pdf->Cell(0,12,'House Name : '. $row['house_name'],0,1);
// $pdf->Cell(0,12,'State : '. $row['state'],0,1);
// $pdf->Cell(0,12,'District : '. $row['district'],0,1);
// $pdf->Cell(0,12,'Email : '. $row['email'],0,1);
$pdf->Cell(0,12,'Phone Number : '. $row['phone'],0,1);
$pdf->Cell(0,12,'address : '. $row['adress'],0,1);
$pdf->Cell(0,12,'Product Name : '. $row['pname'],0,1);
$pdf->Cell(0,12,'Quantity : '. $row['qty'],0,1);
$pdf->Cell(0,12,'Price: '. $row['price'],0,1);
$pdf->Cell(0,12,'Date : '. $row['date'],0,1);
// $pdf->Cell(0,12,'Blood : '. $row['blood'],0,1);




$pdf->Output();
?>