<?php
session_start();	
if (! empty($_SESSION['logged_in'])) {
	# code...
?>
<?php
include('../connection.php');	
if(isset($_POST['submit']))
{
	$category=$_POST['category'];
	$productname=$_POST['pname'];
	$pdesc=$_POST['pdesc'];
	$price=$_POST['price'];
	$qty=$_POST['qty'];
	
	//$productdescription=$_POST['description'];
    $productimage=$_FILES["pimg"]["name"];
 
     $valid=mysqli_query($con,"select * from product where pname='$productname'");
if(mysqli_num_rows($valid)>0){
	echo"<script>alert('product already exists')</script>";
	echo"<script>location=addproduct.php</script>";
}else{
    //for getting product id
    $query=mysqli_query($con,"select max(pid) as pid from product");
	$result=mysqli_fetch_array($query);
	$productid=$result['pid']+1;
	$dir="../productimages/$productid";
if(!is_dir($dir)){
		mkdir("../productimages/".$productid);
	}

	move_uploaded_file($_FILES["pimg"]["tmp_name"],"../productimages/$productid/".$_FILES["pimg"]["name"]);
$sql=mysqli_query($con,"insert into product(category,pname,pdesc,price,qty,pimg,status) values('$category','$productname','$pdesc','$price','$qty','$productimage','active')");

}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Dashboard</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
				 <h1>
                    <a href="">...........Admin</a>
                </h1>
                    <div class="header-mobile-inner">
                       <a class="logo" href="index.php">
                            <img src="" alt="" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    <!--</div>-->
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                <!--<li>
                                    <a href="index.html">Dashboard 1</a>
                                </li>-->
                                
                        <!-- <li>
                            <a href="userapproval.php">
                                <i class="fas fa-chart-bar"></i>User Approval</a>
                        </li> -->
                        <li>
                            <a href="addproduct.php">
                                <i class="fas fa-table">Add Products</i></a>
                        </li>
						<li>
                            <a href="insert_category.php">
                                <i class="fas fa-table">Add Products</i></a>
                        </li>
                        <li>
                            <a href="viewuser.php">
                                <i class="far fa-check-square"></i>View Customers</a>
                        </li>
						<li>
                            <a href="viewuser.php">
                                <i class="far fa-check-square"></i>View Farmers</a>
                        </li>
                        
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
		<div class="header-mobile__bar">
                <div class="container-fluid">
		<h1>
                    <a href="">....Admin......</a>
                </h1>
           <!-- <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>-->
            <div class="menu-sidebar__content js-scrollbar1">
			
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="ii.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                
                            </ul>
                        </li>
                        <li>
                            <a href="farmeruser.php">
                                <i class="fas fa-chart-bar"></i>Farmer Approval</a>
                        </li>
         
         
						<li>
                            <a href="insert_category.php">
                                <i class="far fa-check-square"></i>Add Category</a>
                        </li>
						<li>
                            <a href="viewcategory.php">
                                <i class="fas fa-table"></i>View Category</a>
                        </li>
						<li>
                            <a href="addproduct.php">
                                <i class="fas fa-table"></i>Add Products</a>
                        </li>
						<li>
                            <a href="viewproduct.php">
                                <i class="fas fa-table"></i>View Products</a>
                        </li>
                        <li>
                            <a href="viewusers.php">
                                <i class="far fa-check-square"></i>View Customers</a>
                        </li>
						<li>
                            <a href="viewfarmers.php">
                                <i class="far fa-check-square"></i>View Farmers</a>
                        </li>
						
						
                       
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section_content section_content--p30">
                    <div class="container-fluid">
                       <div class="header-wrap">
                           <form class="form-header" action="" method="POST">
                               
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <!-- <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-comment-more"></i>
                                        <span class="quantity">1</span> -->
                                        <div class="mess-dropdown js-dropdown">
                                            <div class="mess__title">
                                                
                                            </div>
                                          
                                    </div>
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <!-- <img src="images/icon/avatar-01.jpg" alt="Jacob" /> -->
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">Admin</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <!-- <a href="#">
                                                        <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                                    </a> -->
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#">Admin</a>
                                                    </h5>
                                                    <span class="email"></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                               
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="../logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section_content section_content--p20">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                               <div class="overview-wrap">
                                  
                                    <button class="au-btn au-btn-icon au-btn--blue">
                                       
                                </div>
                            </div>
                        </div>
                       
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin panel</title>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Modernize Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
    <!-- //Meta Tags -->

    <!-- Style-sheets -->
    <!-- Bootstrap Css -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Bootstrap Css -->
    <!-- Common Css -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!--// Common Css -->
    <!-- Fontawesome Css -->
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <!--// Fontawesome Css -->
    <!--// Style-sheets -->

    <!--web-fonts-->
    <link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!--//web-fonts-->
    <script type="text/javascript">
function valid()
{
if(document.form7.pname.value=="")
{
alert("enter the program name");
document.form7.pname.focus();
return false;
}
if(!isNaN(document.form7.pname.value))
{
alert("enter alphabets only");
document.form7.pname.focus();
return false;
}
if(document.form7.pdesc.value=="")
{
alert("Enter your discription");
document.form7.pdesc.focus();
return false;
}
if(document.form7.price.value=="")
{
alert("Enter price");
document.form7.price.focus();
return false;
}
if(document.form7.pimg.value=="")
{
alert("Enter the file");
document.form7.pimg.focus();
return false;
}
}
</script>

</head>

<body>
<form action="" method="post" name="form7" enctype="multipart/form-data">
    <div class="bg-page py-5">
        <div class="container">
            <!-- main-heading -->
            <h2 class="main-title-w3layouts mb-2 text-center text-white">Add products</h2>
            <!--// main-heading -->
            <div class="form-body-w3-agile text-center w-lg-50 w-sm-75 w-50 mx-auto mt-5">
                <form  method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Product name</label>
                        <input type="text" class="form-control" placeholder="enter product" id="pname" name="pname"  required onchange="Validate();">
						</div>
						<span id="msg1" style="color:red;"></span>
						<script>		
function Validate() 
{
    var val = document.getElementById('pname').value;

    if (!val.match(/^[A-Z][A-Za-z/ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('pname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
                    <div class="form-row">
                            <div class="name">Category</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="category">
                                        <option value="">Select Category</option>
                                            <?php $query=mysqli_query($con,"select * from category");
                                          while($row=mysqli_fetch_array($query))
                                          {?>

                                            <option value="<?php echo $row['cid'];?>"><?php echo $row['cname'];?>
                                            </option>
                                            <?php } ?>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                    <div class="form-group">
                        <label>Add description</label>
                        <textarea type="text" class="form-control" placeholder="description" name="pdesc"></textarea>
                    </div>
                   <div class="form-group">
                        <label>Add Price</label>
                         <input type="number" class="form-control" placeholder=" Enter Price" id="price" name="price" required onchange="Validat();">
						 <span id="msg4" style="color:red;"></span>
						 <script>
function Validat() 
{
    var val = document.getElementById('price').value;

    if (!val.match(/^[1-9][0-9]*$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed";
	
		
		            document.getElementById('price').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}

</script>
<div class="form-group">
                        <label>Add Quantity</label>
                         <input type="number" class="form-control" placeholder=" Enter Quantity" id="qty" name="qty" required onchange="Validat2();">
						 <span id="msg5" style="color:red;"></span>
						 <script>
function Validat2() 
{
    var val = document.getElementById('qty').value;

    if (!val.match(/^[1-9][0-9]*$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed";
	
		
		            document.getElementById('qty').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

</script>

                    </div>
					<div class="form-group">
                        <!-- <label>Product Availability</label>
<div class="form-controls">
<select   name="productAvailability"  id="productAvailability" type="option" required>
<option value="">Select</option>
<option value="In Stock">In Stock</option>
<option value="Out of Stock">Out of Stock</option>
</select
</div>-->
</div>
                     <div class="form-group">
                        <label>Upload img</label>
                        <input type="file" class="form-control" name="pimg">
                    </div>
                    <input type="submit" name="submit"  value="Add product" onClick="return valid()" class="btn btn-primary error-w3l-btn mt-sm-5 mt-3 px-4">
                </form>
               
                <h1 class="paragraph-agileits-w3layouts mt-2">
                    <a href="ii.php">Back to Home</a>
                </h1>
            </div>
   
<!--if($result>0)
{
echo "<script>
window.onload=function()
{
alert('successfully  added awareness programs.....!');
window.location='addawarenessprograms.php';
}
</script>";
}



}
?>-->
                <!--// Grids I
            <!-- Copyright -->
            <div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center">
                <!--<p>© 2022 Admin panel . All Rights Reserved 
                    <a href="http://w3layouts.com/">  </a>-->
                </p>
            </div>
            <!--// Copyright -->
        </div>
    </div>


    <!-- Required common Js -->
    <script src='js/jquery-2.2.3.min.js'></script>
    <!-- //Required common Js -->

    <!-- Js for bootstrap working-->
    <script src="js/bootstrap.min.js"></script>
    <!-- //Js for bootstrap working -->

</body>

</html>
<?php
}
else
header('location:../login.php');
?>