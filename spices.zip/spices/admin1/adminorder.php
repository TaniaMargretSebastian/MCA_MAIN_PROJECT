<?php
session_start();
if (! empty($_SESSION['logged_in'])) {
    
# code...
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Dashboard</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
				 <h1>
                    <a href="adminindex.php">.....Admin...</a>
                </h1>
                    <!--<div class="header-mobile-inner">
                       <a class="logo" href="index.php">
                            <img src="" alt="" />
                        </a>-->
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    <!--</div>-->
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                <!--<li>
                                    <a href="index.html">Dashboard 1</a>
                                </li>-->
                                
                        <!-- <li>
                            <a href="userapproval.php">
                                <i class="fas fa-chart-bar"></i>Customer Approval</a>
                        </li> -->
                          <li>
                            <a href="farmeruser.php">
                                <i class="fas fa-chart-bar"></i>Farmer Approval</a>
                        </li>
                        <li>
                            <a href="addproduct.php">
                                <i class="fas fa-table">Add Products</i></a>
                        </li>
						<li>
                            <a href="viewproduct.php">
                                <i class="fas fa-table">View Products</i></a>
                        </li>
						<li>
                            <a href="insert_category.php">
                                <i class="fas fa-table">Add Category</i></a>
                        </li>
                        <li>
                            <a href="viewuser.php">
                                <i class="far fa-check-square"></i>viewuser</a>
                        </li>
                        
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
		<div class="header-mobile__bar">
                <div class="container-fluid">
		 <h1>
                    <a href="">.....Admin....</a>
                </h1>
           <!-- <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>-->
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="ii.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                
                            </ul>
                        </li>
                        <!-- <li>
                            <a href="ii.php">
                                <i class="fas fa-chart-bar"></i>Customer Approval</a>
                        </li> -->
<li>
                            <a href="farmeruser.php">
                                <i class="fas fa-chart-bar"></i>Farmer Approval</a>
                        </li>
         
         
						<li>
                            <a href="insert_category.php">
                                <i class="far fa-check-square"></i>Add Category</a>
                        </li>
						<li>
                            <a href="viewcategory.php">
                                <i class="fas fa-table"></i>View Category</a>
                        </li>
						<li>
                            <a href="addproduct.php">
                                <i class="fas fa-table"></i>Add Products</a>
                        </li>
						<li>
                            <a href="viewproduct.php">
                                <i class="fas fa-table"></i>View Products</a>
                        </li>
                        <li>
                            <a href="viewusers.php">
                                <i class="far fa-check-square"></i>View Customers</a>
                        </li>
						<li>
                            <a href="viewfarmers.php">
                                <i class="far fa-check-square"></i>View Farmers</a>
                        </li>
                        <li>
                            <a href="adminorders.php">
                                <i class="far fa-check-square"></i>View Orders</a>
                        </li>
						
                    
                </nav>
            </div>
			</div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section_content section_content--p30">
                    <div class="container-fluid">
                       <div class="header-wrap">
                           <form class="form-header" action="" method="POST">
                               <!-- <input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>-->
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <div class="">
                                        <i class=""></i>
                                        <span class="quantity"></span>
                                        <div class="mess-dropdown js-dropdown">
                                            <div class="mess__title">
                                               
                                            </div>
                                           <!-- <div class="notifi__footer">
                                                <a href="#">All notifications</a>-->
                                          <!--  </div>-->
                                       <!-- </div>-->
                                    </div>
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <!-- <div class="image">
                                            <img src="images/icon/avatar-06.jpg" alt="Jacob" />
                                        </div> -->
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">Admin</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <!-- <a href="#">
                                                        <img src="images/icon/avatar-06.jpg" alt="Jacob" />
                                                    </a> -->
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#">Admin</a>
                                                    </h5>
                                                    <span class="email"></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                               
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="../logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        <!-- /. NAV SIDE  -->
     


         
   
            <!-- Grids Content -->
           <div class="outer-w3-agile mt-2">
                    <h4 class="tittle-w3-agileits mb-4"> View Orders</h4>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                
                                <th>customer name</th>
<!-- <th>Email</th> -->
<th>Phone number</th>
<th>address</th>
<th>total amount</th>
 <th>Date</th>
<th>Status</th> -->
<th class="text-center"align="center">
                                    Action
                                   
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                           
                          <?php
include('../connection.php');
                            
                            $result=mysqli_query($con,"SELECT register.loginid, register.fname, register.phone, register.adress,order_tbl.price, order_tbl.id, order_tbl.status,order_tbl.date FROM register LEFT JOIN order_tbl ON register.loginid = order_tbl.userid where status='placed'");
                                        

while($p=mysqli_fetch_assoc($result))
{?>
<tr>
  <td><?php echo $p['fname'];?></td>
        <td><?php echo $p['phone'];?></td>
<td><?php echo $p['adress'];?></td> 
<td><?php echo $p['price'];?></td>
<td><?php echo $p['date'];?></td>
<td><?php echo $p['status'];?></td>
<!-- <td><?php echo $r['cvcode'];?></td> -->
 <td><button><a style="color:bluek" href="dispatch.php?id=<?php echo $p['id'];?>"><b>Dispatch</a></button></td> 
<!--<a style="background-color:#F63" href="order.php?id=<?php echo $r['pid'];?>"><b>ORDER NOW</a></p><hr>-->
          </tr>
                      <?php
}
?></tbody>
<tfoot></tfoot>
                    </table>
                </div>
                <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>
              <!--// Grids Info -->
</body>
               </html>

           
                                   
 <?php
}
else
header('location:../login/login.php');
?>