<?php
include('../connection.php');
$sid = $_GET['id'];
//$sql = mysqli_query($con,"SELECT * FROM tbl_cart where orderid='$sid'");
 $q=mysqli_query($con,"select * from order_tbl where id='$sid'");
 while($res=mysqli_fetch_array($q))
 
{
$n=mysqli_query($con,"UPDATE order_tbl SET status='Delivered' WHERE id='$sid'");

header('location:adminorder.php');
}
?>