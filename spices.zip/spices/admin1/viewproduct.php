<?php
session_start();
if (! empty($_SESSION['logged_in'])) {
	# code...
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Dashboard</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
				 <h1>
                    <a href="">...........Admin</a>
                </h1>
                    <div class="header-mobile-inner">
                       <a class="logo" href="index.php">
                            <img src="" alt="" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    <!--</div>-->
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                <!--<li>
                                    <a href="index.html">Dashboard 1</a>
                                </li>-->
                                
                        <!-- <li>
                            <a href="userapproval.php">
                                <i class="fas fa-chart-bar"></i>User Approval</a>
                        </li> -->
                        <li>
                            <a href="addproduct.php">
                                <i class="fas fa-table">Add Products</i></a>
                        </li>
						<li>
                            <a href="insert_category.php">
                                <i class="fas fa-table">Add Products</i></a>
                        </li>
                        <li>
                            <a href="viewuser.php">
                                <i class="far fa-check-square"></i>View Customers</a>
                        </li>
						<li>
                            <a href="viewuser.php">
                                <i class="far fa-check-square"></i>View Farmers</a>
                        </li>
                        
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
		<div class="header-mobile__bar">
                <div class="container-fluid">
		<h1>
                    <a href="">....Admin......</a>
                </h1>
           <!-- <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>-->
            <div class="menu-sidebar__content js-scrollbar1">
			
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="ii.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                
                            </ul>
                        </li>
                        <!-- <li>
                            <a href="ii.php">
                                <i class="fas fa-chart-bar"></i>Customer Approval</a>
                        </li> -->
<li>
                            <a href="farmeruser.php">
                                <i class="fas fa-chart-bar"></i>Farmer Approval</a>
                        </li>
         
         
						<li>
                            <a href="insert_category.php">
                                <i class="far fa-check-square"></i>Add Category</a>
                        </li>
						<li>
                            <a href="viewcategory.php">
                                <i class="fas fa-table"></i>View Category</a>
                        </li>
						<li>
                            <a href="addproduct.php">
                                <i class="fas fa-table"></i>Add Products</a>
                        </li>
						<li>
                            <a href="viewproduct.php">
                                <i class="fas fa-table"></i>View Products</a>
                        </li>
                        <li>
                            <a href="viewusers.php">
                                <i class="far fa-check-square"></i>View Customers</a>
                        </li>
						<li>
                            <a href="viewfarmers.php">
                                <i class="far fa-check-square"></i>View Farmers</a>
                        </li>
						
                       
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section_content section_content--p30">
                    <div class="container-fluid">
                       <div class="header-wrap">
                           <form class="form-header" action="" method="POST">
                               
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <!-- <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-comment-more"></i> -->
                                        <span class="quantity"></span>
                                        <div class="mess-dropdown js-dropdown">
                                            <div class="mess__title">
                                                
                                            </div>
                                          
                                    </div>
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <!-- <div class="image">
                                             <img src="images/icon/avatar-06.jpg" alt="Jacob" />
                                        </div> -->
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">Admin</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <!-- <div class="image">
                                                    <a href="#">
                                                         <img src="images/icon/avatar-06.jpg" alt="Jacob" />
                                                    </a>
                                                </div> -->
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#">Admin</a>
                                                    </h5>
                                                    <span class="email"></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                               
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="../logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section_content section_content--p20">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                               <div class="overview-wrap">
                                  
                                    <button class="au-btn au-btn-icon au-btn--blue">
                                       
                                </div>
                            </div>
                        </div>
                       
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin panel</title>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Modernize Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
    <!-- //Meta Tags -->

    <!-- Style-sheets -->
    <!-- Bootstrap Css -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Bootstrap Css -->
    <!-- Common Css -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!--// Common Css -->
    <!-- Fontawesome Css -->
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <!--// Fontawesome Css -->
    <!--// Style-sheets -->

    <!--web-fonts-->
    <link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!--//web-fonts-->
    <script type="text/javascript">
function valid()
{
if(document.form7.pname.value=="")
{
alert("enter the program name");
document.form7.pname.focus();
return false;
}
if(!isNaN(document.form7.pname.value))
{
alert("enter alphabets only");
document.form7.pname.focus();
return false;
}
if(document.form7.pdesc.value=="")
{
alert("Enter your discription");
document.form7.pdesc.focus();
return false;
}
if(document.form7.price.value=="")
{
alert("Enter price");
document.form7.price.focus();
return false;
}
if(document.form7.pimg.value=="")
{
alert("Enter the file");
document.form7.pimg.focus();
return false;
}
}
</script>
</head>

<body>
<form action="" method="post" name="form7" enctype="multipart/form-data">
    <div class="bg-page py-5">
        <div class="container">
            <!-- main-heading -->
            <h2 class="main-title-w3layouts mb-2 text-center text-white">View products</h2>
            <!--// main-heading -->
            
   
<!--if($result>0)
{
echo "<script>
window.onload=function()
{
alert('successfully  added awareness programs.....!');
window.location='addawarenessprograms.php';
}
</script>";
}



}
?>--><section class="grids-section bd-content">

                <!-- Grids Info -->
                <div class="outer-w3-agile mt-2">
                    <h4 class="tittle-w3-agileits mb-4">Products</h4>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Product Name</th>
								  <!--<th>Date</th>-->
                                <th>Discription</th>
								 <th>Price</th>
								 <th>Quantity</th>
								<!-- <th>productAvailability</th>-->
								 
								 <th>Image</th>
                                 <th class="text-center"align="center">
                                    Action
                                    
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                           
                          <?php
						include '../connection.php';
$sql="select * from product WHERE status='active'";
$result = mysqli_query($con, $sql);
//$r= mysqli_fetch_assoc($result);
while($r=mysqli_fetch_array($result))
{?>
		<tr><td><?php echo $r['pname'];?></td>
		<td><?php echo $r['pdesc'];?></td>
		   <td><?php echo $r['price'];?></td>
       <td><?php echo $r['qty'];?></td>
		<!--<td><?php echo $r['price'];?></td>-->
		<!--<td><?php echo $r['productAvailability'];?></td>-->
        <td><img src="../uploads/<?php echo $r['pimg'];?>" width="100" height="100"></td>
		       
                <td><a style="color:#F63" href="update.php?pid=<?php echo $r['pid'];?>"><b>Update</a></td>
				<td><a style="color:#F63" href="deleteproduct.php?pid=<?php echo $r['pid'];?>"><b>Disable</a></td></tr>
                      <?php
}
?></tbody>
                    </table>
                </div>
                <section class="grids-section bd-content">

                <!-- Grids Info -->
                <div class="outer-w3-agile mt-2">
                    <h4 class="tittle-w3-agileits mb-4"> Inactive Products</h4>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Product Name</th>
								  <!--<th>Date</th>-->
                                <th>Discription</th>
								 <th>Price</th>
								 <th>Quantity</th>
								<!-- <th>productAvailability</th>-->
								 
								 <th>Image</th>
                                 <th class="text-center"align="center">
                                    Action
                                    
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                           
                          <?php
						include '../connection.php';
$sql="select * from product WHERE status='inactive'";
$result = mysqli_query($con, $sql);
//$r= mysqli_fetch_assoc($result);
while($r=mysqli_fetch_array($result))
{?>
		<tr><td><?php echo $r['pname'];?></td>
		<td><?php echo $r['pdesc'];?></td>
		   <td><?php echo $r['price'];?></td>
       <td><?php echo $r['qty'];?></td>
		<!--<td><?php echo $r['price'];?></td>-->
		<!--<td><?php echo $r['productAvailability'];?></td>-->
        <td><img src="../uploads/<?php echo $r['pimg'];?>" width="100" height="100"></td>
		       
                <td><a style="color:#F63" href="update.php?pid=<?php echo $r['pid'];?>"><b>Update</a></td>
				<td><a style="color:#F63" href="activepro.php?pid=<?php echo $r['pid'];?>"><b>Enable</a></td></tr>
                      <?php
}
?></tbody>
                    </table>
                </div>
				
                <!--// Grids I
            <!-- Copyright -->
            <div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center">
                <!--<p>© 2022 Admin panel . All Rights Reserved 
                    <a href="http://w3layouts.com/">  </a>-->
                </p>
            </div>
            <!--// Copyright -->
        </div>
    </div>


    <!-- Required common Js -->
    <script src='js/jquery-2.2.3.min.js'></script>
    <!-- //Required common Js -->

    <!-- Js for bootstrap working-->
    <script src="js/bootstrap.min.js"></script>
    <!-- //Js for bootstrap working -->

</body>

</html>
 <?php
}
else
header('location:../login.php');
?> 