<?php
session_start();
if (! empty($_SESSION['logged_in'])) {
	# code...
?>
<?php      
    include '../connection.php';
    $pid=$_GET['pid'];
    $sql="select *from `product` where pid='$pid'";
    $result=mysqli_query($con,$sql);
   $row=mysqli_fetch_assoc($result);
    $pname=$row['pname'];
    $pdesc = $row['pdesc'];
    $price = $row['price'];
	$qty   = $row['qty'];
    //$pimg = $row['pimg'];
    //$officer_email = $row['officer_email'];
    //$officer_password = $row['officer_password'];

    if(isset($_POST['s']))
    {
    $pid=$_GET['pid']; 
    $pname = $_POST['pname'];
    $pdesc = $_POST['pdesc'];
    $price = $_POST['price'];
	$qty2   = $_POST['qty'];
    //$pimg = $_FILES['pimg']['name'];
	//move_uploaded_file($_FILES["pimg"]["tmp_name"],"../productimages/$pid/".$_FILES["pimg"]["name"]);
	//move_uploaded_file($_FILES['pimg']['tmp_name'],"../productimages/".$pimg);
	//if($_FILES['pimg']['name']=='')
        //{
            //$path=$_POST['old'];
       // }
      //  else {
                //$pimg=$_FILES['pimg']['name'];
                //$pimg_tmp=$_FILES['files']['tmp_name'];
                //$path="../upload/".$pimg;
				//move_uploaded_file($_FILES['pimg']['tmp_name'],"../uploads/".$pimg);
               
            //}
	
    //$officer_email = $_POST['email'];
   // $officer_password = $_POST['password'];
    $upqty=$qty+$qty2;
   
        mysqli_query($con,"UPDATE `product` SET `pname`='$pname',`pdesc`='$pdesc',`price`='$price',`qty`='$upqty' where pid='$pid'");
    
            echo "<script>alert('Updated');</script>";
            header('location: viewproduct.php');
     }
  
      
    
 ?>
 
 <!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: lightblue;  
}  
.container {  
    padding: 50px;  
  background-color: white;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style> 
<style> form{
  padding: 150px 170px;
}</style> 
</head>  
<body>  
<form method='post' action="" >  
  
  <div class="container">  
  <center>  <h1>Update Product</h1> </center>  
  <hr>  
  <div class="modal-header">
 
                          </div>
                      <div class="modal-body">
                     <div class="card-body card-block">
                     <div class="form-group">
                        <label for="company" class=" form-control-label">Product Name</label>
                   <input type="text"   class="form-control" name="pname"  id="pname" readonly  required onchange="validate();"  onfocusout="f1()" value="<?php echo $pname?>">
				   <span id="msg1" style="color:red;"></span>
							<script>		
function Validate() 
{
    var val = document.getElementById('pname').value;

    if (!val.match(/^[A-Z][A-Za-z/ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('pname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Discription </label>
                    <input type="text"  class="form-control" name="pdesc" id="station"  value="<?php echo $pdesc?>">
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">price</label>
                    <input type="number"  class="form-control" name="price"  id="price" required onchange="Validat();"  onfocusout="f1()" value="<?php echo $price?>">
					<span id="msg4" style="color:red;"></span>
						 <script>
function Validat() 
{
    var val = document.getElementById('price').value;

    if (!val.match(/^[1-9][0-9]*$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed ";
	
		
		            document.getElementById('price').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}

</script>
<div class="form-group">
                        <label for="company" class=" form-control-label">Quantity</label>
                    <input type="number"  class="form-control" name="qty"  id="qty" required onchange="Validat12();"  onfocusout="f1()" value="<?php echo $qty?>">
					<span id="msg5" style="color:red;"></span>
						 <script>
function Validat12() 
{
    var val = document.getElementById('qty').value;

    if (!val.match(/^[1-9][0-9]*$/))
    {
        document.getElementById('msg5').innerHTML="Only Numbers are allowed ";
	
		
		            document.getElementById('qty').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

</script>

                </div>
                
                </div>
                
                
               
                
            </div>  
                     
                </div>
            <div class="modal-footer">
                     <a id="" href="addproduct.php" color="white"> Cancel</a>
                    <button type="submit" class="btn btn-primary" name="s">Update</button>
            </div>
                   
            </div>
                </div>
            
</form>  
</body>  
</html>
<?php
}
else
header('location:../login.php');
?>