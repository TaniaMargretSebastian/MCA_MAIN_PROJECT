<?php
session_start();
if (! empty($_SESSION['logged_in'])) {
	# code...
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Agrox | Contact</title>
<meta charset="utf-8">
<!--<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">-->
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<style>
a, abbr, acronym, address, applet, article, aside, audio, b, blockquote, big, body, center, canvas, caption, cite, code, command, datalist, dd, del, details, dfn, dl, div, dt, em, embed, fieldset, figcaption, figure, font, footer, form, h1, h2, h3, h4, h5, h6, header, hgroup, html, i, iframe, img, ins, kbd, keygen, label, legend, li, meter, nav, object, ol, output, p, pre, progress, q, s, samp, section, small, span, source, strike, strong, sub, sup, table, tbody, tfoot, thead, th, tr, tdvideo, tt, u, ul, var {
	background:transparent;
	border:3px;
	font-size:100%;
	margin:0;
	padding:0;
	border:0;
	outline:0;
	vertical-align:top
}
ol, ul {
	list-style:none
}
blockquote, q {
	quotes:none
}
table, table td {
	padding:0;
	border:none;
	border-collapse:collapse
}
img {
	vertical-align:top
}
embed {
	vertical-align:top
}
* {
	border:none
}
</style>
<script type="text/javascript" src="js/jquery-1.6.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/tms-0.3.js"></script>
<script type="text/javascript" src="js/tms_presets.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">#menu a, .bg, .bg2, #ContactForm a {behavior:url("../js/PIE.htc")}</style>
<![endif]-->
</head>
<body id="page5">
<div class="body1">
  <div class="main">
    <!--header -->
    <header>
      <div class="wrapper">
        <h1><a href="index.php" id="logo"></a></h1>
        <nav>
          <ul id="menu">
            <li class="active"><a href="index1.php">Home</a></li>
            <li><a href="products.php">About</a></li>
            <li><a href="contact.php">contact</a></li>
            <li><a href="viewproduct.php">Sign_up</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
      </div>
    </header>
    <!-- / header -->
    <!-- content -->
  </div>
</div>
<!--<div class="body2">
  <div class="main">
    <article id="content2">
      <div class="wrapper">
        <div class="col1">
          <h2>Our Contacts</h2>
          <p class="color1"></p>
          <ul class="address">
            <li>4567 adc road kottyam kerala</li>
            <li>
              <pre>Freephone: +1 800 559 6580</pre>
            </li>
            <li>
              <pre>Telephone: +1 959 603 6035</pre>
            </li>
            <li>
              <pre>E-mail: <a href="#">spices@splink.org</a></pre>
            </li>
          </ul>
          <p></p>
        </div>
        <div class="cols pad_left1">
          <h2>Feel Free to Contact Us</h2>
          <figure class="left marg_right1"><img src="images/.jpg" alt=""></figure>
          <p class="color1 pad_bot1">If you require any further information, please feel free to contact me.</p>
          <p class="pad_bot1"></p>
          <p></p>
        </div>
      </div>
    </article>
    <!-- / content -->
  </div>
</div>-->
<!--<div class="main">
  <!-- footer -->
  <!--<footer>
    <div class="wrapper">
      <section class="col2">
        <div class="wrapper">
          <section class="col4">
            <h3>Follow Us </h3>
            <ul id="icons">
              <li><a href="#"><img src="images/icon1.jpg" alt=""><span>Facebook</span></a></li>
              <li><a href="#"><img src="images/icon2.jpg" alt=""><span>Twitter</span></a></li>
              <li><a href="#"><img src="images/icon3.jpg" alt=""><span>Linked In</span></a></li>
            </ul>
          </section>-->
          <!--<section class="col4 pad_left1">
            <h3>Why Us </h3>
            <ul id="why_us">
              <li><a href="#">Sed perspiciatis unde </a></li>
              <li><a href="#">Omnis natus error</a></li>
              <li><a href="#">Voluptatem accusantium </a></li>
            </ul>-->
         <!-- </section>
        </div>
        <div id="footer_link">Copyright &copy; <a href="#">Domain Name</a> All Rights Reserved<br>
          Design by <a target="_blank" href="http://www.templatemonster.com/">TemplateMonster.com</a></div>
      </section>-->
      <!--<section class="col3 pad_left2">
        <h3>Email Us</h3>-->
       <!-- <form id="ContactForm" action="#">
          <div>
            <div class="wrapper"> <span>Your Name:</span>
              <div class="bg">
                <input type="text" class="input">
              </div>
            </div>
            <div class="wrapper"> <span>Your E-mail:</span>
              <div class="bg">
                <input type="text" class="input">
              </div>
            </div>
            <div class="textarea_box"> <span>Your Message:</span>
              <div class="bg2">
                <textarea name="textarea" cols="1" rows="1"></textarea>
              </div>
            </div>
            <a href="#">Submit</a> </div>
        </form>-->
      </section>
    </div>
    <!-- {%FOOTER_LINK} -->
  </footer>
  <!-- / footer -->
</div>
</body>
</html>
<?php
}
else
header('location:login.php');
?>