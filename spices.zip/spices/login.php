<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.6.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/tms-0.3.js"></script>
<script type="text/javascript" src="js/tms_presets.js"></script>
<script type="text/javascript" src="js/script.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Login Page </title>
    <style>
        html {
            background: #6696cc;
background: url(images/img1.jpg) no-repeat 0px 0px;
background-size : cover;

       
        }
       
        .body-content {
            padding-top: 20vh;
        }
       
        .container {
            width: 350px;
            height: 400px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin: auto;
            border: 6px solid White;
            border-radius: 35px;
            background: white;
        }
       
        .logo {
            margin-bottom: 10px;
            margin-top: 0px;
            padding-top: 0;
        }
       
        .logo img {
            width: 100px;
            margin: 10px;
            border-radius: 45px;
        }
       
        form {
            display: flex;
            flex-direction: column;
        }
       
        .form-item {
            margin: 5px;
            padding-bottom: 10px;
            display: flex;
        }
       
        .form-item label {
            display: block;
            padding: 2px;
            font-size: 20px;
            width: 100px;
        }
       
        .form-item input {
            width: 320px;
            height: 35px;
            border: 2px solid #e1dede69;
            border-radius: 20px;
            background: #e1dede69;
            color: grey;
        }
       
        .form-btns {
            display: flex;
            flex-direction: column;
            margin: auto;
            padding: 10px 0;
        }
       
        .form-btns button {
            margin: auto;
            font-size: 20px;
            padding: 5px 15px;
            border: 2px solid;
            border-radius: 15px;
            color: white;
            background: #178cc6;
            width: 280px;
            cursor: pointer;
        }
       
        .options {
            padding-top: 15px;
            margin: auto;
        }
       
        .options a {
            text-decoration: none;
            color: black;
            margin: 0 40px;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 15px;

        }
        .options a:hover {
            color: grey;
 
        }
       
        p {
            text-align: center;
            font-size: 10px;
            font-family: Arial, Helvetica, sans-serif;
        }
    </style>
</head>

<body style="background-color:white;">
<div class="main">
    <!--header -->
    <header>
      <div class="wrapper" style="background-color:white; width: 1200px; padding-right: 200px;">
        <h1><a href="index.php" id="logo">MountainFresh Products</a></h1>
        <nav>
          <ul id="menu">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="products.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="signup.php">Sign up</a></li>
			<li><a href="login.php">Sign in</a></li>
          </ul>
        </nav>
    </div>
    <div class="body-content">

        <div class="container">
            <div class="logo">
                <image src="images/logo1.jpg" alt="Boutique logo" srcset="">
            </div>
            <div class="login-form">
                <form action="loginAcc.php" method="post">
                    <div class="form-item">
                        <!-- <label for="userName">Username:</label> -->
                        <input type="text" name="username" id="username" placeholder="Username">
                    </div>
                    <div class="form-item">
                        <!-- <label for="passWord">Password:</label> -->
                        <input type="password" name="password" id="password" placeholder="Password">
                    </div>


                    <div class="form-btns">

                        <button type="submit">Login</button>
                        <div class="options">
                           <a href="index.php">Home</a>
						    <a href="signup.php">Create Account</a>
                            <!--<a href="lo.php"></a>-->
                        </div>
                    </div>
<!--<a href="../index.html">Home</a>-->
                </form>
                <!--<p>Copyright &copy; mountainfresh@gmail.com</p>-->
            </div>
        </div>
    </div>
</body>

</html>
