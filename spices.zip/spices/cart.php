<?php
include 'connection.php';
session_start();
error_reporting(0);
$uid = $_SESSION['id'];
if($_SESSION['id']==""){
  header('location:login.php');
  $sid=$_GET['id'];
}
?>
<?php

if(isset($_POST['remove'])){

$cartid = $_POST['id'];
$quan = $_POST['quantity'];
$sqlls = "DELETE from tbl_cart where id=$cartid";
mysqli_query($con,$sqlls);
echo"<script>alert('Item Removed');</script>";
echo"<script>window.location='cart.php?id=$sid';</script>";
}


if(isset($_POST['update'])){
    $price = $_POST['totalprice'];
    $quan = $_POST['quantity'];
    $cartid = $_POST['id'];
    if($quan==0){
        $sqlls = "DELETE from tbl_cart where id=$cartid";
      mysqli_query($con,$sqlls);
     echo"<script>alert('Item Removed');</script>";
     echo"<script>window.location='cart.php?id=$sid';</script>";

    }
    else{
        $s =mysqli_query($con,"select * from tbl_cart where id='$cartid'");
        $d =mysqli_fetch_array($s);
        $y =$d['price'];
        $totalprice=$quan*$y;
    $sqll = "UPDATE tbl_cart SET quantity=$quan,totalprice=$totalprice where id=$cartid";
    mysqli_query($con,$sqll);
    
    echo"<script>alert('Cart Updated');</script>";
    echo"<script>window.location='cart.php?id=$sid';</script>";
    }
}

if(isset($_POST['order'])){
    
    $sid=$_GET['id'];
	$car2 = mysqli_query($con,"SELECT * FROM `tbl_cart` where userid=$uid ");
    
                                    $qq = mysqli_query($con,"SELECT SUM(totalprice) FROM `tbl_cart` WHERE status='0' AND userid='$uid'");
                                    while($er=mysqli_fetch_array($qq)){
                                        $p=$er['SUM(totalprice)'];
                                    ?>
                                    <div class="ml-auto h5"> <?php echo $p ?> </div>
                                    <?php } ?>
                                    <?php
    while($row = mysqli_fetch_array($car2))
    {
	$quantity=$row['quantity'];
    $price=$row['totalprice'];
    $cartid = $_POST['id'];
    $da=date('d-m-y');
    }
	$order="INSERT INTO `order_tbl`(`userid`, `cartid`, `price`,`status`,`date`) VALUES ('$uid', '$cartid', '$p','placed','$da')";
	$or1=mysqli_query($con,$order);

	

	//$sq==mysqli_query($con,"delete from tbl_cart");
$a=mysqli_query($con,"select max(id) from order_tbl");
$v=mysqli_fetch_array($a);
$inv=$v[0];
$n=mysqli_query($con,"update tbl_cart set orderid='$inv'");
$sqll=mysqli_query($con,"insert into tbl_cart1 select * from tbl_cart");
$scrc=mysqli_query($con,"select * from tbl_cart");
while($result=mysqli_fetch_array($scrc))
{
    $pid=$result['pid'];
    $quantity=$result['quantity'];
    $n=mysqli_query($con,"update product set qty=qty-$quantity where pid='$pid'");
}

	echo"<script>window.location='checkout.php?pid=$sid';</script>";
}

?>

<script>
function remove()
{
if(confirm("Do you want to remove this item"))
{
	return true;
}
else{
	return false;
}
}                      
 </script>


<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title></title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="csss/css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="csss/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="csss/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="csss/css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
              
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                
                
                   
                  
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt=""  style="height: 124px;width: 147px;"></a>
                    <div class="brand_name">
                    <h2 style="margin-top: 10px;font-family: 'Montserrat';font-weight: 600;">MountainFresh<br>Products<h2>
                    
                    </div>

                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                       <!-- <li class="nav-item"><a class="nav-link" href="index.php">HOME</a></li>-->
                        <li class="nav-item "><a class="nav-link" href="shop.php?pid=1" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Shop</a></li>
                       
                        <li class="nav-item"><a class="nav-link" href="my-account.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Account</a></li>
                        <li class="nav-item"><a class="nav-link" href="orderview.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Order</a></li>
						<li class="nav-item active"><a class="nav-link" href="cart.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Cart</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="logout.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Logout</a></li>
                    </ul>
                    <div class="w3l_header_right">
		
		<!-- <form class="example" action="search.php" method="POST">
        <input type="text" placeholder="Search.." name="search" >
        <button type="submit"><i class="fa fa-search" ></i></button>
        </form>
				 -->
		
		</div>
                </div>
                
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
               
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
            <div class="side">
            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                <li class="cart-box">
                    <!-- <ul class="cart-list">
                    <!-- <?php  
                            $result = mysqli_query($con,"SELECT tbl_cart.userid,tbl_cart.price,tbl_cart.totalprice, tbl_cart.pid,product.pname, product.pimg FROM tbl_cart LEFT JOIN product ON tbl_cart.pid = product.pid where userid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?> -->
                    
                        <li>
                            
                            <a href="#" class="photo"><img src="productimages/<?php echo $raw['pid']; ?>/<?php echo $raw['pimg']; ?>" class="cart-thumb" alt="" /></a>
                            <h6><a href="#"> <?php echo $raw['pname']; ?></a></h6>
                            <!--<h6>By:<a href="#"> <?php echo $raw['product_company']; ?></a></h6>-->
                            
                            <p>1x - <span class="price"><?php echo $raw['price']; ?></span></p>
                        </li>
                        
                        <?php } ?>
                        
                       
                        <li class="total"> 
                          <a href="cart.php" class="btn btn-default hvr-hover btn-cart">VIEW CART</a>
                        </li>
                        
                        
                        	 
                    </ul>
                </li> -->
            </div>
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    

    <!-- Start Top Search -->
 
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box" style="background-image: url('images/img1.jpg');">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="font-size: 45px;font-weight: 900; padding-left: 80px;">My Cart</h2>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Cart  -->
    <div class="cart-box-main">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-main table-responsive">
                    <form name="cart" method="POST" enctype="multipart/form-data">
  
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Images</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody> 
                             
                            	<?php
                                $sql2 = "SELECT * from tbl_cart where status='0' AND userid=$uid";
                                $price=mysqli_query($con,$sql2);
                                $cart = mysqli_fetch_array($price);
                                ;			
                                $result = mysqli_query($con,"SELECT tbl_cart.id,tbl_cart.price,tbl_cart.quantity,tbl_cart.totalprice, tbl_cart.pid,product.pname, product.pimg FROM tbl_cart LEFT JOIN product ON tbl_cart.pid = product.pid where tbl_cart.status='0' AND userid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){
                                    $amount = $raw['price'] * $raw['quantity'] ; ?>
                            
                                <tr>
                                    <td class="thumbnail-img">
                                        <a href="#">
									<img class="img-fluid" src="productimages/<?php echo $raw['pid']; ?>/<?php echo $raw['pimg']; ?>" alt="" />
								</a>
                                    </td>
                                    <td class="name-pr">
                                    <input type="hidden" name="id" value="<?php echo $raw['id']; ?>">
                                        <a href="#">
                                        <?php echo $raw['pname']; ?>
								</a>
                                    </td>
                                    <td class="price-pr">
                                        <input type="text" name="price" value="<?php echo $raw['price']; ?>" style="border: none;ont-family: 'Quattrocento Sans', sans-serif;color:#666666">
                                    </td>
                                    <?php
                                     $sid=$_GET['id'];
                                     $sql = mysqli_query($con,"SELECT * FROM product where pid='$sid'");
                                     $k = mysqli_fetch_array($sql);

                                    ?>
                                    <td class="quantity-box"><input type="number" name="quantity" size="4" value="<?php echo $raw['quantity']; ?>" min="1" max="<?php echo $k['qty'] ?>" step="1" class="c-input-text qty text"></td>
                                    <td class="total-pr">
                                    <input type="text" name="totalprice" value="<?php echo $amount ?>" style="border: none;ont-family: 'Quattrocento Sans', sans-serif;color:#666666">
                                    </td>
                                    <td class="remove-pr">
                                        <button name="remove" onclick="return remove()" style="border: none;background-color: red;">
									<i class="fas fa-times"></i>
								</button>
                                
                                    </td>
                                 
                                </tr>
                                <?php }  ?>
                               
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>

            <div class="row my-5">
                
                <div class="col-lg-6 col-sm-6">
                    <div class="update-box">
                        <input value="Update Cart" type="submit" name="update">
                    </div>
                </div>
                <div class="col-lg-6 col-sm-6">
                    <div class="update-box">
                        <input value="Place Order" type="submit" name="order" >
                    </div>
                </div>
            </div>
            </form>
            

          
        </div>
    </div>
    <!-- End Cart -->

   

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>
<?php
header('location:../login.php');
?>
