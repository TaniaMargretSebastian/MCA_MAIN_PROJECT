<?php
    include 'connection.php';
  //$cno = $_REQUEST['con_no'];
    $fname = $_POST['fname'];
	//$lname = $_POST['lname'];
    $email = $_POST['email'];
	$adress = $_POST['adress'];
    $phone = $_POST['phone'];
	//$gender = $_POST['gender'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $s = "SELECT * FROM login WHERE username = '$email'";
    $role=$_POST['type1'];
	
    $result1 = mysqli_query($con, $s);
    $row1=mysqli_fetch_assoc($result1);
    $uname= isset($row1['username']) ? $row1['username'] : '';
	
    if($uname=="")
    {
            if($password===$confirm_password)
            {
            $sq = "INSERT INTO login (username,password,type1,status) VALUES ('$email','$password','$role','0')";
            
             mysqli_query($con, $sq);

              $sqll = "SELECT * FROM login WHERE username = '$email' and password = '$password' and type1 = '$role'";
             $result = mysqli_query($con, $sqll);
            $no=mysqli_num_rows($result);
        
            if($no > 0)
            {
             $row=mysqli_fetch_assoc($result);
             $email=$row['username'];
             $loid=$row['loginid'];
             $sql = "INSERT INTO register (loginid,fname,email,adress,phone,estatus) VALUES ('$loid','$fname','$email','$adress','$phone','0')";
             mysqli_query($con, $sql);
             header("location:src/verifymail2.php?email=$email");
             }
         }
         else
            echo "<script> alert('please enter password correctly'); window.location.href='signup.php';</script>";
}
else
echo "<script> alert('You are already registered'); window.location.href='index.php';</script>"

?>