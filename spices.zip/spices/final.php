<?php
include 'connection.php';
session_start();
error_reporting(0);
$uid = $_SESSION['id'];
if($_SESSION['id']==""){
  header('location:login.php');
}
?>

<!DOCTYPE html>
<html>

<head>
    <title></title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="csss/css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="csss/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="csss/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="csss/css/custom.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <style type="text/css">
        body,
        table,
        td,
        a {
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }

        table,
        td {
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        img {
            -ms-interpolation-mode: bicubic;
        }

        img {
            border: 0;
            height: auto;
            line-height: 100%;
            outline: none;
            text-decoration: none;
        }

        table {
            border-collapse: collapse !important;
        }

        body {
            height: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
        }

        a[x-apple-data-detectors] {
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        @media screen and (max-width: 280px) {
            .mobile-hide {
                display: none !important;
            }

            .mobile-center {
                text-align: center !important;
            }
        }

        div[style*="margin: 16px 0;"] {
            margin: 0 !important;
        }
    </style>

<body style="margin: 0 !important; padding: 0 !important; background-color: #eeeeee;" bgcolor="#eeeeee">
<div class="main-top">
        <div class="container-fluid">
            <div class="row">
              
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                
                
                   
                  
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt=""  style="height: 124px;width: 147px;"></a>
                    <div class="brand_name">
                    <h2 style="margin-top: 10px;font-family: 'Montserrat';font-weight: 600;">MountainFresh<br>Products<h2>
                    
                    </div>

                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                       <!-- <li class="nav-item"><a class="nav-link" href="index.php">HOME</a></li>-->
                        <li class="nav-item active"><a class="nav-link" href="shop.php?pid=1" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Shop</a></li>
                       
                        <li class="nav-item"><a class="nav-link" href="my-account.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Account</a></li>
                        <li class="nav-item"><a class="nav-link" href="orderview.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Order</a></li>
						<li class="nav-item"><a class="nav-link" href="cart.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Cart</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="logout.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Logout</a></li>
                    </ul>
                    <div class="w3l_header_right">
		
		<form class="example" action="search.php" method="POST">
        <input type="text" placeholder="Search.." name="search" >
        <button type="submit"><i class="fa fa-search" ></i></button>
        </form>
				
		
		</div>
                </div>
                
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
               
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
            <div class="side">
            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                <li class="cart-box">
                    <ul class="cart-list">
                    <?php  
                            $result = mysqli_query($con,"SELECT tbl_cart.userid,tbl_cart.price,tbl_cart.totalprice, tbl_cart.pid,product.pname, product.pimg FROM tbl_cart LEFT JOIN product ON tbl_cart.pid = product.pid where userid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                    
                        <li>
                            
                            <a href="#" class="photo"><img src="productimages/<?php echo $raw['pid']; ?>/<?php echo $raw['pimg']; ?>" class="cart-thumb" alt="" /></a>
                            <h6><a href="#"> <?php echo $raw['pname']; ?></a></h6>
                            <!--<h6>By:<a href="#"> <?php echo $raw['product_company']; ?></a></h6>-->
                            
                            <p>1x - <span class="price"><?php echo $raw['price']; ?></span></p>
                        </li>
                        
                        <?php } ?>
                        
                       
                        <li class="total"> 
                          <a href="cart.php" class="btn btn-default hvr-hover btn-cart">VIEW CART</a>
                        </li>
                        
                        
                        	 
                    </ul>
                </li>
            </div>
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    
   
    <!-- Start All Title Box -->
    <div class="all-title-box" style="background-image: url('images/img1.jpg')";>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="font-size: 57px; margin-left: 110px;}"></h2>
                   
                </div>
            </div>
        </div>
    </div>
                                </nav>
                                </header>
    <div style="display: none; font-size: 1px; color: #fefefe; line-height: 1px; font-family: Open Sans, Helvetica, Arial, sans-serif; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden;">
        For what reason would it be advisable for me to think about business content? That might be little bit risky to have crew member like them.
    </div>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td align="center" style="background-color: #eeeeee;" bgcolor="#eeeeee">
                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
                    <tr>
                        <td align="center" valign="top" style="font-size:0; padding: 25px;" bgcolor="#FFFF00">
                            <div style="display:inline-block; max-width:50%; min-width:50px; vertical-align:top; width:100%;">
                                <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:100px;">
                                    <tr>
                                        <td align="left" valign="top" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 36px; font-weight: 800; line-height: 48px;" class="mobile-center">
                                            <h1 style="font-size: 36px; font-weight: 800; margin: 0; color: #333333;">MountainFresh Products</h1>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div style="display:inline-block; max-width:50%; min-width:100px; vertical-align:top; width:100%;" class="mobile-hide">
                                <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:300px;">
                                    <tr>
                                        <td align="right" valign="top" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; line-height: 48px;">
                                            <table cellspacing="0" cellpadding="0" border="0" align="right">
                                                <tr>
                                                    <td style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400;">
                                                        <p style="font-size: 18px; font-weight: 400; margin: 0; color: #ffffff;"><a href="cart.php" target="_blank" style="color: #333333; text-decoration: none;">Shop &nbsp;</a></p>
                                                    </td>
                                                    <td style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 24px;"> <a href="#" target="_blank" style="color: #ffffff; text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/small-business.png" width="27" height="23" style="display: block; border: 0px;" /></a> </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style="padding: 35px 35px 20px 35px; background-color: #ffffff;" bgcolor="#ffffff">
                            <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
                            <?php
                            $result=mysqli_query($con,"SELECT register.loginid, register.fname, register.phone, register.adress,order_tbl.price, order_tbl.status,order_tbl.date FROM register LEFT JOIN order_tbl ON register.loginid = order_tbl.userid where userid='$uid'");
                            while($p=mysqli_fetch_array($result))
                            {
                            $fname=$p['fname'];
                            $phone=$p['phone'];
                            $adress=$p['adress'];
                            $price=$p['price'];
                            $date=$p['date'];
                            //$status=$p['status'];
                            }                      
                            
                            ?>
                                <tr>
                                    <td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;"> <img src="https://img.icons8.com/carbon-copy/100/000000/checked-checkbox.png" width="125" height="120" style="display: block; border: 0px;" /><br>
                                        <h2 style="font-size: 20px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;">Name: <?php echo $fname ?></h2>
                                        <h3 style="font-size: 20px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;">Phone no: <?php echo $phone ?></h3>
                                        <h4 style="font-size: 20px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;">Address: <?php echo $adress ?></h4>
                                        <h5 style="font-size: 20px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;">Total Price: <?php echo $price ?></h5>
                                        <h6 style="font-size: 20px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;">Date: <?php echo $date ?></h6>
                                        <!-- <h7 style="font-size: 20px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;">Product Status: <?php echo $status ?></h7> -->
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                                        <p style="font-size: 16px; font-weight: 400; line-height: 24px; color: #777777;"></p>
                                    </td>
                                </tr>
                                
                                
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" height="100%" valign="top" width="100%" style="padding: 0 35px 35px 35px; background-color: #ffffff;" bgcolor="#ffffff">
                            <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:660px;">
                                
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style=" padding: 35px; background-color: #FFFF00;" bgcolor="#1b9ba3">
                            <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
                              
                                <tr>
                                    <td align="center" style="padding: 25px 0 15px 0;">
                                        
                                        <br>
                                        <table border="0" cellspacing="0" cellpadding="0">
                                        <?php
                    $sp=mysqli_query($con,"SELECT * from order_tbl where userid='$uid'");
                    $ek=mysqli_fetch_array($sp);
                    $cartid=$ek['cartid'];
                    ?>
                                            <tr>
                                                <td align="center" style="border-radius: 5px;" bgcolor="#84C639"> <a href="billpdf.php?cid=<?php echo $cartid ?>" target="_blank" style="font-size: 18px; font-family: Open Sans, Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; border-radius: 5px; background-color: #010101; padding: 15px 30px; border: 1px solid #F44336; display: block;">Bill Generation</a> </td>
                                            </tr>
                                            <?php
                    $sp=mysqli_query($con,"SELECT * from order_tbl where userid='$uid'");
                    $ek=mysqli_fetch_array($sp);
                    $userid=$ek['userid'];
                    ?>
                                            <tr>
                                                <td align="center" style="border-radius: 5px;" bgcolor="#84C639"> <a href="payment.php?id=<?php echo $userid ?>" target="_blank" style="font-size: 18px; font-family: Open Sans, Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; border-radius: 5px; background-color: #010101; padding: 15px 30px; border: 1px solid #F44336; display: block;">Payment</a> </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
    
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
</body>

</html>
<?php
header('location:../login.php');
?>
