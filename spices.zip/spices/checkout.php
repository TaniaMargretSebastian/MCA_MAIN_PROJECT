<?php
include 'connection.php';
session_start();
error_reporting(0);
$uid = $_SESSION['id'];
$pid=$_GET['pid'];
if($_SESSION['id']==""){
  header('location:login.php');
}
$sql = mysqli_query($con,"SELECT * from tbl_cart where status='0' AND userid='$uid'");
while($row=mysqli_fetch_array($sql)){
  $cartid = $row['id'];
  $price = $row['totalprice'];
  
  
  
 
}
$pid =$row['pid'];
$sqll = mysqli_query($con,"SELECT * from product where pid='$pid'");
   $pname = $row['pname'];
   if(isset($_POST['update']))
	{
		$fname=$_POST['fname'];
		$phone=$_POST['phone'];
		$adress=$_POST['adress'];
		$query=mysqli_query($con,"update register set fname='$fname',phone='$phone',adress='$adress' where loginid='$uid'");
		if($query)
		{
echo "<script>alert('Your info has been updated');</script>";
		}
	}


?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title></title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="csss/css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="csss/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="csss/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="csss/css/custom.css">

    
</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
               
                
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt=""  style="height: 124px;width: 147px;"></a>
                    <div class="brand_name">
                    <h2 style="margin-top: 10px;font-family: 'Montserrat';font-weight: 600;">MountainFresh<br>Products<h2>
                    
                    </div>

                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="shop.php?pid=1" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Shop</a></li>
                       
                        
                       
                        <li class="nav-item"><a class="nav-link" href="my-account.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Account</a></li>
						<li class="nav-item"><a class="nav-link" href="cart.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Cart</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Logout</a></li>
                    </ul>
                </div>
               
            </div>
          
        </nav>
        <!-- End Navigation -->
    </header>
    
    <div class="all-title-box" style="background-image: url('images/img1.jpg');">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="font-size: 45px;font-weight: 900;">Checkout</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="shop.php?pid=1">Shop</a></li>
                        <li class="breadcrumb-item active"><a href="shop.php?pid=1">Checkout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Cart  -->
    <div class="cart-box-main">
        <div class="container">
           
            <div class="row">
                <div class="col-sm-6 col-lg-6 mb-3">
                    <div class="checkout-address">
                        <div class="title-left">
                            <h3>Billing address</h3>
                        </div>
                        
                        <form class="needs-validation" novalidate>
                            <div class="row">
                                
                            </div>
                            <div class="mb-3">
                            <?php
                $result = mysqli_query($con,"SELECT * FROM register where loginid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                                <label for="username"> </label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="username" placeholder="<?php echo $raw['fname']; ?>" readonly>
                                   
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="email">Email Address </label>
                                <input type="email" class="form-control" id="email" placeholder="<?php echo $raw['email']; ?>" readonly>
                                
                            </div>
                            <div class="mb-3">
                                <label for="email">Contact Number </label>
                                <input type="email" class="form-control" id="phone" placeholder="<?php echo $raw['phone']; ?>" readonly>
                                
                            </div>
                            <div class="mb-3">
                                <label for="address">Address </label>
                                <input type="text" class="form-control" id="address" placeholder="<?php echo $raw['adress']; ?>" readonly>
                            
                            </div>
                                <?php } ?>
                                
                                
                                
                            
                            <!-- <div class="row">
                                <div class="col-md-5 mb-3">
                                
                        <div class="title-right">
                            <h3>Shipping address</h3>
                        </div>
                        
                        <form class="needs-validation" novalidate>
                            <div class="row">
                                
                            </div>
                            <div class="mb-3">
                            <?php
                $result = mysqli_query($con,"SELECT * FROM register where loginid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                                <label for="username"> </label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="username" name="fname" placeholder="<?php echo $raw['fname']; ?>" >
                                   
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="email">Email Address </label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="<?php echo $raw['email']; ?>" readonly>
                                
                            </div>
                            <div class="mb-3">
                                <label for="email">Contact Number </label>
                                <input type="email" class="form-control" id="phone" name="phone" placeholder="<?php echo $raw['phone']; ?>" >
                                
                            </div>
                            <div class="mb-3">
                                <label for="address">Address </label>
                                <input type="text" class="form-control" id="address" name="adress" placeholder="<?php echo $raw['adress']; ?>" >
                                <button type="submit" name="update" class="btn btn-primary">Submit</button>
                            
                            </div>
                            </div>
                                <div class="col-md-4 mb-3">
                                   
                                </div>
                                <div class="col-md-3 mb-3">
                                    
                                </div>
                            </div>
                            <hr class="mb-4"> 
                                  <?php
                                }
                                ?> -->
                                
                                
                          
                           
                        <div class="col-md-12 col-lg-12">
                            <div class="odr-box">
                                <div class="title-left">
                                    <h3>Shopping cart</h3>
                                </div>
                                <div class="rounded p-2 bg-light">
                                    <div class="media mb-2 border-bottom">
                                    <?php
                                $result = mysqli_query($con,"SELECT tbl_cart.id,tbl_cart.price,tbl_cart.quantity,tbl_cart.totalprice, tbl_cart.pid,product.pname, product.pimg FROM tbl_cart LEFT JOIN product ON tbl_cart.pid = product.pid where userid='$uid' and tbl_cart.status='0'");
                                while ($raw = mysqli_fetch_array($result)){
                                    $qua= $raw['quantity'];
                                    $pname=$raw['pname'];
                                     ?>
                                        <div class="media-body"> <a href="cart.php"> <?php echo $raw['pname']; ?></a>

                                            <div class="small text-muted">Price: <?php echo $raw['price']; ?> <span class="mx-2">|</span> Qty: <?php echo $raw['quantity']; ?>  Subtotal: <?php echo $raw['totalprice']; ?> </div>
                                        </div>
                                    </div>
                                <?php } ?>
                                   
                                   
                            </div>
                        </div>
                    
                        <div class="col-md-12 col-lg-12">
                            <div class="order-box">
                                <div class="title-left">
                                    <h3>Your order</h3>
                                </div>
                                <div class="d-flex">
                                    <div class="font-weight-bold">Product</div>
                                    <div class="ml-auto font-weight-bold">Total</div>
                                </div>
                              
                            
                          
                               
                                <hr>
                                <div class="d-flex gr-total">
                                    <h5>Grand Total</h5>
                                    <?php
                                    $qq = mysqli_query($con,"SELECT SUM(totalprice) FROM `tbl_cart` WHERE status='0' AND userid='$uid'");
                                    while($er=mysqli_fetch_array($qq)){
                                    ?>
                                    <div class="ml-auto h5"> <?php echo $er['SUM(totalprice)']; ?> </div>
                                    <?php } ?>
                                </div>
                                <hr> </div>
                                <?php

                                    // $sql = mysqli_query($con,"SELECT * from tbl_cart where userid='$uid'");
                                    // $row=mysqli_fetch_array($sql);
                                    // $pid =$row['pid'];

                                    $pid=$_GET['pid'];
                                


                                ?>
                        </div>
                        
<div class="col-12 d-flex shopping-box"> <a href="orderaction.php?cid=<?php echo $cartid ?>&&pname=<?php echo $pname ?>&&pid=<?php echo $pid ?>&&price=<?php echo $price ; ?>&&qua=<?php echo  $qua ?>" class="ml-auto btn hvr-hover">Place Order</a> </div>
                    </div>
                    

                </div>
            </div>

        </div>
    </div>
    <!-- End Cart -->

    
    <!-- Start copyright  -->
    <!--<div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2018 <a href="#">ThewayShop</a> Design By :
            <a href="https://html.design/">html design</a></p>
    </div>
     End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>
<?php
header('location:../login.php');
?>
