<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.6.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/tms-0.3.js"></script>
<script type="text/javascript" src="js/tms_presets.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">#menu a, .bg, .bg2, #ContactForm a {behavior:url("../js/PIE.htc")}</style>
<![endif]-->
</head>
<body id="page1">
<div class="body1">
  <div class="main">
    <!--header -->
    <header>
      <div class="wrapper">
        <h1><a href="index.php" id="logo">MountainFresh Products</a></h1>
        <nav>
          <ul id="menu">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="products.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="signup.php">Sign up</a></li>
			<li><a href="login.php">Sign in</a></li>
          </ul>
        </nav>
      </div>
      <div class="slider_bg">
        <div class="slider">
          <ul class="items">
            <li><img src="images/img1.jpg" alt=""></li>
            <li><img src="images/th.jpg" alt=""></li>
            <li><img src="images/t1.jpg" alt=""></li>
          </ul>
        </div>
      </div>
    </header>
    <!-- / header -->
    <!-- content -->
    <article id="content">
      <div class="wrapper">
        <h2>MountainFresh Products</h2>
        <div class="wrapper">
          <section class="col1"> <span class="dropcap1"><span>a</span></span>
            <div class="cols">
              <p class="pad_bot1 color1">MountainFresh welcomes you to a healthy and hygienic world of spices with our aim to provide authentic Indian spices to our consumers while maintaining the highest quality & hygiene standards. </p>
              <p class="pad_bot2"></p>
              <!--<a href="#" class="link1">Read More</a><--> </div>
          </section>
          <section class="col1 pad_left1"> <span class="dropcap1"><span class="color1">b</span></span>
            <div class="cols">
              <p class="pad_bot1 color1">Our raw materials are procured from the places of their origin. Our highly developed infrastructural facility is upgraded on a regular basis and all the spices are processed and blended in automatic machines at every stage and before packing</p>
              <p class="pad_bot2"></p>
             <!-- <a href="#" class="link1">Read More</a><--> </div>
          </section>
          <!--<section class="col1 pad_left1"> <span class="dropcap1"><span class="color2">c</span><--></span>
            <div class="cols">
              <p class="pad_bot1 color1"></p>
              <p class="pad_bot2"><a href="index.php" class="link2"></a>, <a href="products.php" class="link2"></a>, <a href="s" class="link2"</a>, <a href="pricing.html" class="link2"></a> <a href="login.php" class="link2"></a></p>
              <!--<a href="#" class="link1">Read More</a><--> </div>
          </section>
        </div>
      </div>
    </article>
  </div>
</div>
<div class="body2">
  <div class="main">
    <article id="content2">
      <div class="wrapper">
        <section class="col2">
          <h2><span></span></h2>
          <div class="testimonials">
            <p class="quot">A spice is a seed, fruit, root, bark, or other plant substance primarily used for flavoring or coloring food. Spices are distinguished from herbs, which are the leaves, flowers, or stems of plants used for flavoring or as a garnish<img src="images/quot2.png" alt=""></p>
          </div>
          <p class="pad_bot1"><em class="font1 color1"></em></p>
          <div class="wrapper">
           <section class="col4">
              <!--<ul class="list1">
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
              </ul>
            </section>
            <section class="col4 pad_left1">
              <ul class="list1">
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
              </ul>-->
            </section>
          </div>
        </section>
        <section class="col3 pad_left2">
          <h2>Our Products</h2>
          <div class="wrapper pad_top1">
            <figure class="left marg_right1"><img src="images/pep.jpg" alt=""></figure>
            <p><span class="font1 color2">Pepper</span><br>
              Pepper is the berry of Piper nigrum, a climbing perennial shrub &nbsp; <!--<a href="#" class="link1">Read More</a>--> </p>
          </div>
          <div class="wrapper">
            <figure class="left marg_right1"><img src="images/clo.jpg" alt=""></figure>
            <p><span class="font1 color2">Cloves</span><br>
              Clove is most commonly recognized as a spice used for cooking, &nbsp; <!--<a href="#" class="link1">Read More</a>--> </p>
          </div>
          <div class="wrapper">
            <figure class="left marg_right1"><img src="images/ca.jpg" alt=""></figure>
            <p><span class="font1 color2">Cardamom</span><br>
              Cardamom is a spice made from the seed pods of various plants in the ginger family. &nbsp; <!--<a href="#" class="link1">Read More</a>--> </p>
          </div>
        </section>
      </div>
    </article>
    <!-- / content -->
  </div>
</div>
<div class="main">
  <!-- footer -->
  <footer>
    <div class="wrapper">
      <section class="col2">
        <div class="wrapper">
          <section class="col4">
           <!-- <h3>Follow Us </h3>
            <ul id="icons">
              <li><a href="#"><img src="images/icon1.jpg" alt=""><span>Facebook</span></a></li>
              <li><a href="#"><img src="images/icon2.jpg" alt=""><span>Twitter</span></a></li>
              <li><a href="#"><img src="images/icon3.jpg" alt=""><span>Linked In</span></a></li>
            </ul>-->
          </section>
          <!--<section class="col4 pad_left1">
            <h3>Why Us </h3>
            <ul id="why_us">
              <li><a href="#">Sed perspiciatis unde </a></li>
              <li><a href="#">Omnis natus error</a></li>
              <li><a href="#">Voluptatem accusantium </a></li>
            </ul>
          </section>
        </div>
        <div id="footer_link">Copyright &copy; <a href="#">Domain Name</a> All Rights Reserved<br>
          Design by <a target="_blank" href="http://www.templatemonster.com/">TemplateMonster.com</a></div>
     </section>-->
      <!--<section class="col3 pad_left2">
        <h3>Email Us</h3>
        <form id="ContactForm" action="#">
          <div>
            <div class="wrapper"> <span>Your Name:</span>
              <div class="bg">
                <input type="text" class="input">
              </div>
            </div>
            <div class="wrapper"> <span>Your E-mail:</span>
              <div class="bg">
                <input type="text" class="input">
              </div>
            </div>
            <div class="textarea_box"> <span>Your Message:</span>
              <div class="bg2">
                <textarea name="textarea" cols="1" rows="1"></textarea>
              </div>
            </div>
            <a href="#">Submit</a> </div>
        </form>
      </section>
    </div>-->
    <!-- {%FOOTER_LINK} -->
  </footer>
  <!-- / footer -->
</div>
</body>
</html>