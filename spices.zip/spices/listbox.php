<?php 
  include 'connection.php';
session_start(); 
error_reporting(0);
$uid = $_SESSION['id'];
if($_SESSION['id']==""){
  header('location:login.php');
}
$sql = mysqli_query($con,"SELECT * from register where id='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['fname'];
 
}
  $sid=1;
  $sid = $_GET['aid'];
  $sql = mysqli_query($con,"SELECT * FROM product where pid='$sid'");
  
  
  if(isset($_POST['cart'])){
    $productid = intval($_POST['productid']);
    $product = "SELECT * from product where pid=$productid";
    $products = mysqli_query($con,$product);
    $row = mysqli_fetch_assoc($products); 
    $totalprice=0;
    $price=$row['price'];
    // $totalprice=$quantity*$price;
  
   // $size = $_POST['size'];
    $quantity=$_POST['quantity'];
    $totalprice=$quantity*$price;
  
       $s=mysqli_query($con,"select * from tbl_cart where status='0' and userid='$uid' and pid='$sid'");
       
       $h=mysqli_num_rows($s);
       if($h > 0){
        echo "<script>alert('item alredy exists');</script>";
        echo "<script>window.location='cart.php?id=$sid';</script>";
       }else{
    
       $sql2 = "INSERT INTO tbl_cart(userid,pid,quantity,price,totalprice,status) VALUES('$uid','$productid','$quantity','$price','$totalprice','0')";
       $food = mysqli_query($con,$sql2);
       
   
       if (!$food) {
        echo "Error: " . mysqli_error($con);
    }

    echo "<script>location='cart.php?id=$sid'</script>";
      
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>.</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="csss/css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="csss/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="csss/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="csss/css/custom.css">

  

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
               
               
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo1.jpg" class="logo" alt=""  style="height: 124px;width: 147px;"></a>
                    <div class="brand_name">
                    <h2 style="margin-top: 10px;font-family: 'Montserrat';font-weight: 600;">MountainFresh<br>Products<h2>
                    
                    </div>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="my-account.php"></a></li>
                        <li class="nav-item"><a class="nav-link" href="shop.php?pid=1" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Shop</a></li>
                       
                        <li class="nav-item"><a class="nav-link" href="my-account.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Account</a></li>
                        <li class="nav-item"><a class="nav-link" href="orderview.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Order</a></li>
						<li class="nav-item"><a class="nav-link" href="cart.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">My Cart</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="logout.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Logout</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                
            </div>
            <!-- Start Side Menu -->
            <div class="side">
            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                <li class="cart-box">
                    <ul class="cart-list">
                    <?php  
                            $result = mysqli_query($con,"SELECT tbl_cart.userid,tbl_cart.price,tbl_cart.totalprice, tbl_cart.product.pname, product.pimg FROM tbl_cart LEFT JOIN product ON tbl_cart.pid = product.pid where userid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                    
                        <li>
                            
                            <a href="#" class="photo"><img src="productimages/<?php echo $raw['pid']; ?>/<?php echo $raw['pimg']; ?>" class="cart-thumb" alt="" /></a>
                            <h6><a href="#"> <?php echo $raw['pname']; ?></a></h6>
                            <!--<h6>By:<a href="#"> <?php echo $raw['product_company']; ?></a></h6>-->
                            
                            <p>1x - <span class="price"><?php echo $raw['price']; ?></span></p>
                        </li>
                        
                        <?php } ?>
                        
                       
                        <li class="total"> 
                          <a href="cart.php" class="btn btn-default hvr-hover btn-cart">VIEW CART</a>
                        </li>
                        
                        
                        	 
                    </ul>
                </li>
            </div>
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
    <div class="top-search">
        <div class="container">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
            </div>
        </div>
    </div>
    
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Shop Detail  -->
    <div class="shop-detail-box-main">
        <div class="container">
        <form action="" method="POST" >
            <?php while ($row = mysqli_fetch_array($sql)){ ?>
            <div class="row">
         
                <div class="col-xl-5 col-lg-5 col-md-6">
                    <div id="carousel-example-1" class="single-product-slider carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active"> <img class="d-block w-100" src="productimages/<?php echo $row['pid']; ?>/<?php echo $row['pimg']; ?>" alt="First slide"> </div>
                           
                        </div>
                      
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-md-6">
              
                
                    <div class="single-product-details">
                        <h2><?php echo $row['pname']; ?> Per Packet</h2>
                        <h5>RS: <?php echo $row['price']; ?> </h5>
                       
                                <h4>Description</h4>
                                <p><?php echo $row['pdesc']; ?></p>
                                <ul>
                                <input type="hidden" name="productid" value="<?php echo $row['pid']; ?>"> 
                                    
                                    <li>
                                        <div class="form-group quantity-box">
                                            <label class="control-label">Quantity</label>

                                            <input class="form-control" name="quantity" value="1" min="1" max="<?php echo $row['qty']; ?>" type="number">
                                        </div>
                                    </li>
                                </ul>`

                                <div class="price-box-bar">
                                    <div class="cart-and-bay-btn">
                                    
                                    <input type="submit" name="cart" value="Add to Cart" style="height: 43px;color: #fff;  background: #d33b33; border-radius: 5px;width: 98px;font-size: initial;font-weight: 500;}">
                                    


                                     
                                    
                                    </div>
                                </div>
                                <button name="view cart"  style="height: 43px;color: #fff;  background: #d33b33; border-radius: 5px;width: 98px;font-size: initial;font-weight: 500;}"><a href="cart.php" style="color:#fff">View Cart</a></button>

                             
                                
                    </div>
                 

                </div>
                <?php } ?>
                </form>
            
            </div>
           
       
    </div>
    <br>
    <br>
    <br>
    <!-- End Cart -->

    
    <!-- End Footer  -->

    <!-- Start copyright  -->
  <!--  <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2018 <a href="#">ThewayShop</a> Design By :
            <a href="https://html.design/">html design</a></p>
    </div>
     End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>
<?php
header('location:../login.php');
?>
