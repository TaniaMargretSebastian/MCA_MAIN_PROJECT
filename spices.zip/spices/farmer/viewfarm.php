<?php
session_start();
if (! empty($_SESSION['logged_in'])) {
	# code...
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin panel</title>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Modernize Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
    <!-- //Meta Tags -->

    <!-- Style-sheets -->
    <!-- Bootstrap Css -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Bootstrap Css -->
    <!-- Common Css -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!--// Common Css -->
    <!-- Fontawesome Css -->
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <!--// Fontawesome Css -->
    <!--// Style-sheets -->

    <!--web-fonts-->
    <link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
	<header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="../images/logo1.jpg" alt="#" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item">
                                 <a class="nav-link" href="index.php"> Home  </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="Addproduct.php">Add Product</a>
                              </li>
                              <li class="nav-item active">
                                 <a class="nav-link" href="viewfarm.php">View AddProducts </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="my-account.php">Manage Account</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="../logout.php">Logout</a>
                              </li>
                              <li class="nav-item d_none">
                                 <a class="nav-link" href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
                              </li>
                              
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
    <!--//web-fonts-->
    <script type="text/javascript">
function valid()
{
if(document.form7.pname.value=="")
{
alert("enter the program name");
document.form7.pname.focus();
return false;
}
if(!isNaN(document.form7.pname.value))
{
alert("enter alphabets only");
document.form7.pname.focus();
return false;
}
if(document.form7.pdesc.value=="")
{
alert("Enter your discription");
document.form7.pdesc.focus();
return false;
}
if(document.form7.price.value=="")
{
alert("Enter price");
document.form7.price.focus();
return false;
}
if(document.form7.pimg.value=="")
{
alert("Enter the file");
document.form7.pimg.focus();
return false;
}
}
</script>
</head>

<body>
<form action="" method="post" name="form7" enctype="multipart/form-data">
    <div class="bg-page py-5">
	<div style="border:2px solid pink;padding:20px;font-size:20px;background-color:#6495ED">
        <div class="container">
            <!-- main-heading -->
            <h2 class="main-title-w3layouts mb-2 text-center text-white">View products</h2>
            <!--// main-heading -->
            
   
<!--if($result>0)
{
echo "<script>
window.onload=function()
{
alert('successfully  added awareness programs.....!');
window.location='addawarenessprograms.php';
}
</script>";
}



}
?>-->
<section class="grids-section bd-content">

                <!-- Grids Info -->
                <div class="outer-w3-agile mt-2">
                    <h4 class="tittle-w3-agileits mb-4"></h4>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Product Name</th>
								  <!--<th>Date</th>-->
                                <th>Discription</th>
								 <th>Price</th>
								 <th>Image</th>
								<!-- <th>productAvailability</th>-->
								 
								 <th>Quantity</th>
                                 <!-- <th class="text-center"align="center">
                                    Action
                                    
                                </th> -->
                            </tr>
                        </thead>
                        <tbody>
                           
                          <?php
						include '../connection.php';
$sql="select * from product WHERE status='active' AND type='farmer'";
$result = mysqli_query($con, $sql);
//$r= mysqli_fetch_assoc($result);
while($r=mysqli_fetch_array($result))
{?>
		<tr><td><?php echo $r['pname'];?></td>
		<td><?php echo $r['pdesc'];?></td>
		   <td><?php echo $r['price'];?></td>
       <td><?php echo $r['qty'];?></td> 
		<!--<td><?php echo $r['price'];?></td>-->
		<!--<td><?php echo $r['productAvailability'];?></td>-->
        <td><img src="../uploads/<?php echo $r['pimg'];?>" width="100" height="100"></td>
		 <!-- <td><?php echo $r['qty'];?></td> -->
	       
                <!-- <td><a style="color:#F63" href="update.php?pid=<?php echo $r['pid'];?>"><b>Edit</a></td>
				<td><a style="color:#F63" href="deleteproduct.php?pid=<?php echo $r['pid'];?>"><b>Delete</a></td> -->
         </tr>
                      <?php
}
?></tbody>
                    </table>
                </div>
				<!--<h1 class="paragraph-agileits-w3layouts mt-2">
                    <a center href="index.php">Back to Home</a>
                </h1>-->
                <!--// Grids I
            <!-- Copyright -->
            <div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center">
                <!--<p>© 2022 Admin panel . All Rights Reserved 
                    <a href="http://w3layouts.com/">  </a>-->
                </p>
            </div>
            <!--// Copyright -->
        </div>
    </div>


    <!-- Required common Js -->
    <script src='js/jquery-2.2.3.min.js'></script>
    <!-- //Required common Js -->

    <!-- Js for bootstrap working-->
    <script src="js/bootstrap.min.js"></script>
    <!-- //Js for bootstrap working -->

</body>

</html>
<?php
}
else
header('location:../login.php');
?>
