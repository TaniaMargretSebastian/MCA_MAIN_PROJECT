<?php
session_start();
if (! empty($_SESSION['logged_in'])) {
	# code...
?>
 <!-- //Meta Tags -->

    <!-- Style-sheets -->
    <!-- Bootstrap Css -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Bootstrap Css -->
    <!-- Bars Css -->
    <link rel="stylesheet" href="css/bar.css">
    <!--// Bars Css -->
    <!-- Calender Css -->
    <link rel="stylesheet" type="text/css" href="css/pignose.calender.css" />
    <!--// Calender Css -->
    <!-- Common Css -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!--// Common Css -->
    <!-- Nav Css -->
    <link rel="stylesheet" href="css/style4.css">
    <!--// Nav Css -->
    <!-- Fontawesome Css -->
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <!--// Fontawesome Css -->
    <!--// Style-sheets -->

    <!--web-fonts-->
    <link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!--//web-fonts-->

        
            <!-- main-heading -->
            <h2 class="main-title-w3layouts mb-2 text-center"></h2>
            <!--// main-heading -->

          
    
            <!-- Grids Content -->
            <section class="grids-section bd-content">
			
                <!-- Grids Info -->
                <div class="outer-w3-agile mt-3">
                    <h4 class="tittle-w3-agileits mb-4">User Requests</h4>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
								<th class="text-center">
                                    Email
                                   
                                </th>
								 <th class="text-center">
                                 Address
                                    
                                </th>
								 <th class="text-center">
                               Phone
                                    
                                </th>
                                <!--<th class="text-center">
                                    District
                                    
                                </th>
                                <th class="text-center">
                                   Pincode
                                    
                                </th>
								 <th class="text-center">
                                 Gender
                                   
                                </th>-->
								<th class="text-center" colspan="2" align="center">
                                    Action
                                    
                                </th>
                            </tr>
							
                        </thead>
						
						
                        <tbody>
						
						

                           
                         <?php
		include '../connection.php';
   		// $id= $_SESSION['ID'];
        $rs = mysqli_query($con,"SELECT * FROM login WHERE status='0' and type1='farmer' " );
   		while($row1=mysqli_fetch_assoc($rs))
   			{
        	$logid=$row1['loginid'];
    
        	$cs = mysqli_query($con,"SELECT * FROM register WHERE loginid='$logid' " );
  
                while($row=mysqli_fetch_assoc($cs))
                {
                   
                    echo "<tr><td>" . $row['fname'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['adress'] . "</td>";
                    echo "<td>" . $row['phone'] . "</td>";
                    //echo "<td>" . $row['district'] . "</td>";
                    //echo "<td>" . $row['pincode'] . "</td>";
                    //echo "<td>" . $row['gender'] . "</td>";
                    echo "<td>" . "<a id=approve href='approve.php?id=$logid'> Approve</a>". "</td>";
                    echo "<td>" . "<a id=reject href='reject.php?id=$logid'> Reject</a>". "</td>";
                    echo "</tr>";
                }
               
            }
             echo "</table>";
                ?>
				</tbody>
                    </table>
					<div class="account-dropdown__footer">
                                                <a href="../logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
											 <h1 class="paragraph-agileits-w3layouts mt-2">
                    <a href="index.php">Back to Home</a>
                </h1>
                </div>
                <!--// Grids Info -->
                

           
                                   
           
		   <?php
}
else
header('location:../login.php');
?>