<?php
session_start();
$id=$_SESSION['id'];
include '../connection.php';
$q="select * from register where loginid=$id";
$res=mysqli_query($con,$q);
$row=mysqli_fetch_array($res);
if(strlen($_SESSION['logged_in'])==0)
    {   
header('location:login.php');
}
else{
   if(isset($_POST['update']))
	{
		$fname=$_POST['fname'];
		$phone=$_POST['phone'];
		$adress=$_POST['adress'];
		$query=mysqli_query($con,"update register set fname='$fname',phone='$phone',adress='$adress' where loginid='".$_SESSION['id']."'");
		if($query)
		{
echo "<script>alert('Your info has been updated');</script>";
		}
	}
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>MountainFresh Products</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<!-- Fonts -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,700' rel='stylesheet' type='text/css'>

<!-- Css -->
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" />
<link rel="stylesheet" href="css/owl.carousel.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<!-- jS -->
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.nivo.slider.js" type="text/javascript"></script>
<script src="js/owl.carousel.min.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollUp.min.js"></script>
<script src="js/main.js" type="text/javascript"></script>


</head>
<body>


<!-- TOP HEADER Start
    ================================================== -->
	<header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="../images/logo1.jpg" alt="#" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item active">
                                 <a class="nav-link" href="index.php"> Home  </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="Addproduct.php">Add Product</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="viewfarm.php">View AddProducts </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="my-account.php">Manage Account</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="../logout.php">Logout</a>
                              </li>
                              <li class="nav-item d_none">
                                 <a class="nav-link" href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
                              </li>
                              
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>

<section id="top">
<div class="container">
<div class="row">
<div class="col-md-7">
<p class="contact-action"><i class=""></i><strong></strong></p>
</div>

</div> <!-- End Of /.row -->
</div> <!-- End Of /.Container -->



</section>  <!-- End of /Section -->





<nav class="navbar navbar-default">
<div class="container">
   <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
       <span class="sr-only">Toggle navigation</span>
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
     </button>
   </div> <!-- End of /.navbar-header -->

   
<div class="leave-comment">
<form class="form-horizontal" role="form">
<div class="form-group">
    <label for="inputname" class="col-sm-2 control-label">Name</label>
   <div class="col-sm-10">
      <input type="text" value="<?php echo $row['fname'];?>" name="fname" id="fname"required="true" class="form-control" required onchange="Validate();" >
   </div>
  </div>
<span id="msg1" style="color:red;"></span>
<script>
function Validate()
{
    var val = document.getElementById('fname').value;

    if (!val.match(/^[A-Z][A-Za-z]{3,}$/))
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
           document.getElementById('fname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script> <!-- End of /.form-group -->
                             
  <div class="form-group">
    <label for="inputEmail" class="">Email Address</label>
   <div class="col-sm-10">
      <input type="email" class="form-control" value="<?php echo $row['email'];?>" name="email" id="email" required onchange="Validata();"readonly>
   </div>
  </div>
<span id="msg5" style="color:red;"></span>
<script>
function Validata()
{
    var val = document.getElementById('email').value;

    if (!val.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/))
    {
        document.getElementById('msg5').innerHTML="Enter a Valid Email";

    document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

</script> <!-- End of /.form-group -->
  <div class="form-group">
    <label for="inputwebsite" class="">Mobile Number</label>
   <div class="col-sm-10">
      <input type="text" name="phone" class="form-control" value="<?php echo $row['phone'];?>" id="phone" required onchange="Validat();">
   </div>
  </div>
<span id="msg4" style="color:red;"></span>
<script>
function Validat()
{
    var val = document.getElementById('phone').value;

    if (!val.match(/^[789][0-9]{9}$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed and must contain 10 number";


           document.getElementById('phone').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}

</script> <!-- End of /.form-group -->
 
<div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" name="update" class="btn btn-primary">Update</button>
<button type="" class="btn btn-primary"><a href="index.php" >Cancel</a></button>
    </div>
  </div>
</form>
</div>




<!-- FOOTER Start
    ================================================== -->

<footer>
<div class="container">
<div class="row">

</div> <!-- End Of /.row -->
</div> <!-- End Of /.Container -->



<!-- FOOTER-BOTTOM Start
    ================================================== -->

<div class="footer-bottom">
<div class="container">
<div class="row">
<div class="col-md-12">

<p class="copyright-text pull-right"></p>
</div> <!-- End Of /.col-md-12 -->
</div> <!-- End Of /.row -->
</div> <!-- End Of /.container -->
</div> <!-- End Of /.footer-bottom -->
</footer> <!-- End Of Footer -->

<a id="back-top" href="#"></a>
</body>
</html>

