<?php
session_start();
include('../connection.php');
error_reporting(0);	
$q="select * from register where loginid=$id";
$res=mysqli_query($con,$q);
$row=mysqli_fetch_array($res);

if(isset($_POST['submit']))
{
	$category=$_POST['category'];
	$productname=$_POST['pname'];
	
	$price=$_POST['price'];
	$qty=$_POST['qty'];
	
	$productdescription=$_POST['description'];
    $productimage=$_FILES["pimg"]["name"];
 
     $valid=mysqli_query($con,"select * from product where pname='$productname'");
if(mysqli_num_rows($valid)>0){
	echo"<script>alert('product already exists')</script>";
	echo"<script>location=Addproduct.php</script>";
}else{
//for getting product id
    $query=mysqli_query($con,"select max(pid) as pid from product");
	$result=mysqli_fetch_array($query);
	$productid=$result['pid']+1;
	$dir="../productimages/$productid";
if(!is_dir($dir)){
		mkdir("../productimages/".$productid);
	}

	move_uploaded_file($_FILES["pimg"]["tmp_name"],"../productimages/$productid/".$_FILES["pimg"]["name"]);
$sql=mysqli_query($con,"insert into product(category,pname,pdesc,price,qty,pimg,status,type) values('$category','$productname','$productdescription','$price','$qty','$productimage','active','farmer')");

}
}
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin panel</title>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Modernize Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
    <!-- //Meta Tags -->

    <!-- Style-sheets -->
    <!-- Bootstrap Css -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Bootstrap Css -->
    <!-- Common Css -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!--// Common Css -->
    <!-- Fontawesome Css -->
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <!--// Fontawesome Css -->
    <!--// Style-sheets -->

    <!--web-fonts-->
    <link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!--//web-fonts-->
	<header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="../images/logo1.jpg" alt="#" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item active">
                                 <a class="nav-link" href="index.php"> Home  </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="Addproduct.php">Add Product</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="viewfarm.php">View AddProducts </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="my-account.php">Manage Account</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="../logout.php">Logout</a>
                              </li>
                              <li class="nav-item d_none">
                                 <a class="nav-link" href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
                              </li>
                              
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
    <script type="text/javascript">
function valid()
{
if(document.form7.pname.value=="")
{
alert("enter the program name");
document.form7.pname.focus();
return false;
}
if(!isNaN(document.form7.pname.value))
{
alert("enter alphabets only");
document.form7.pname.focus();
return false;
}
if(document.form7.pdesc.value=="")
{
alert("Enter your discription");
document.form7.pdesc.focus();
return false;
}
if(document.form7.price.value=="")
{
alert("Enter price");
document.form7.price.focus();
return false;
}
if(document.form7.pimg.value=="")
{
alert("Enter the file");
document.form7.pimg.focus();
return false;
}
}
</script>
</head>

<body>
<form action="" method="post" name="form7" enctype="multipart/form-data">
    <div class="bg-page py-5">
	<div style="border:2px solid pink;padding:20px;font-size:20px;background-color:#6495ED">
        <div class="container">
            <!-- main-heading -->
            <h2 class="main-title-w3layouts mb-2 text-center text-white">Add products</h2>
            <!--// main-heading -->
            <div class="form-body-w3-agile text-center w-lg-50 w-sm-75 w-50 mx-auto mt-5">
                <form  method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Product name</label>
                        <input type="text" class="form-control" placeholder="enter product" id="pname" name="pname"  required onchange="Validate();">
						</div>
						<span id="msg1" style="color:red;"></span>
						<script>		
function Validate() 
{
    var val = document.getElementById('pname').value;

    if (!val.match(/^[A-Z][A-Za-z/ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('pname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
                    <div class="form-row">
                            <div class="name">Category</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="category">
                                        <option value="">Select Category</option>
                                            <?php $query=mysqli_query($con,"select * from category");
                                          while($row=mysqli_fetch_array($query))
                                          {?>

                                            <option value="<?php echo $row['cid'];?>"><?php echo $row['cname'];?>
                                            </option>
                                            <?php } ?>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                        <label>Add description</label>
                        <textarea type="text" class="form-control" placeholder="description" name="description"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Add Price</label>
                         <input type="number" class="form-control" placeholder=" Enter Price" id="price" name="price" required onchange="Validat();">
						 <span id="msg4" style="color:red;"></span>
						 <script>
function Validat() 
{
    var val = document.getElementById('price').value;

    if (!val.match(/^[1-9][0-9]*$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed";
	
		
		            document.getElementById('price').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}

</script>
                    
<div class="form-group">
                        <label>Add Quantity(kg)</label>
                         <input type="number" class="form-control" placeholder=" Enter Quantity" id="qty" name="qty" required onchange="Validat2();">
						 <span id="msg5" style="color:red;"></span>
						 <script>
function Validat2() 
{
    var val = document.getElementById('qty').value;

    if (!val.match(/^[0-9]+(\.[0-9]{2})?$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed";
	
		
		            document.getElementById('qty').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

</script>

                    </div>
					<div class="form-group">
                        <!-- <label>Product Availability</label>
<div class="form-controls">
<select   name="productAvailability"  id="productAvailability" type="option" required>
<option value="">Select</option>
<option value="In Stock">In Stock</option>
<option value="Out of Stock">Out of Stock</option>
</select
</div>-->
</div>
                     <div class="form-group">
                        <label>Upload img</label>
                        <input type="file" class="form-control" name="pimg">
                    </div>
					<div>
                    <input type="submit" name="submit"  value="Add product" onClick="return valid()" class="btn btn-primary error-w3l-btn mt-sm-5 mt-3 px-4">
                </form>
               
                <h1 class="paragraph-agileits-w3layouts mt-2">
                    <a href="index.php">Back to Home</a>
                </h1>
            </div>
   
<!--if($result>0)
{
echo "<script>
window.onload=function()
{
alert('successfully  added awareness programs.....!');
window.location='addawarenessprograms.php';
}
</script>";
}



}
?>-->
                <!--// Grids I
            <!-- Copyright -->
            <div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center">
                <!--<p>© 2022 Admin panel . All Rights Reserved 
                    <a href="http://w3layouts.com/">  </a>-->
                </p>
            </div>
            <!--// Copyright -->
        </div>
    </div>


    <!-- Required common Js -->
    <script src='js/jquery-2.2.3.min.js'></script>
    <!-- //Required common Js -->

    <!-- Js for bootstrap working-->
    <script src="js/bootstrap.min.js"></script>
    <!-- //Js for bootstrap working -->

</body>

</html>