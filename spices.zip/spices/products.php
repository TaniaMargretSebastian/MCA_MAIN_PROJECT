<!DOCTYPE html>
<html lang="en">
<head>
<title>Agrox | Products</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.6.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/tms-0.3.js"></script>
<script type="text/javascript" src="js/tms_presets.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">#menu a, .bg, .bg2, #ContactForm a {behavior:url("../js/PIE.htc")}</style>
<![endif]-->
</head>
<body id="page2">
<div class="body1">
  <div class="main">
    <!--header -->
    <header>
      <div class="wrapper">
        <h1><a href="index.php" id="logo"></a></h1>
        <nav>
          <ul id="menu">
            <li><a href="index.php">Home</a></li>
            <li class="active"><a href="products.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="signup.php">Sign-up</a></li>
            <li><a href="login.php">Sign-In</a></li>
          </ul>
        </nav>
      </div>
    </header>
    <!-- / header -->
    <!-- content -->
    <article id="content">
      <div class="wrapper">
        <h2>Useful Info</h2>
        <div class="wrapper">
          <section class="col1"> <span class="dropcap1"><span>01</span></span>
            <div class="cols">
              <p class="pad_bot1 color1">Top of the Hill Quality Produce is a favorite of Renton residents and has been for many years. Expect to find the best quality produce as it is hand selected daily. The owners buy locally whenever possible and work with local farmers to ensure you get the freshest product available.</p>
              <p class="pad_bot2">Used in to season and preserve food, and as medicines, dyes, and perfumes.</p>
              <!--<a href="#" class="link1">Read More</a> </div><-->
          </section>
          <section class="col1 pad_left1"> <span class="dropcap1"><span class="color1">02</span></span>
            <div class="cols">
              <p class="pad_bot2">The word spice comes from the Latin species, which means merchandise, or wares.</p>
              <p class="pad_bot1 color1">spices have been highly valued as trade goods for thousands of years</p>
             <!-- <a href="#" class="link1">Read More</a> </div><-->
          </section>
          <section class="col1 pad_left1"> <span class="dropcap1"><span class="color2">03</span></span>
            <div class="cols">
              <p class="pad_bot1 color1">Coffee is a brewed drink prepared from roasted coffee beans, the seeds of berries from certain flowering plants in the Coffea genus. </p>
              <p class="pad_bot2"> From the coffee fruit, the seeds are separated to produce a stable, raw product: unroasted green coffee. </p>
             <!-- <a href="#" class="link1">Read More</a> </div><-->
          </section>
        </div>
      </div>
    </article>
  </div>
</div>
<div class="body2">
  <div class="main">
    <article id="content2">
      <h2>Our Featured Products</h2>
      <div class="wrapper">
        <div class="cols">
          <figure class="pad_bot2 pad_top1"><img src="images/img5.jpg" alt=""></figure>
          <p class="pad_bot2"> <span class="font1 color2">Pepper</span><br>
            <em>Pepper is the berry of Piper nigrum, a climbing perennial shrub.</em><br>
          </p>
         <!-- <a href="#" class="link1">Read More</a><--> </div>
        <div class="cols pad_left1">
          <figure class="pad_bot2 pad_top1"><img src="images/img4.jpg" alt=""></figure>
          <p class="pad_bot2"> <span class="font1 color2">Cloves</span><br>
            <em>Clove is most commonly recognized as a spice used for cooking, but it has also been used for centuries to treat various health concerns</em><br>
          </p>
          <!--<a href="#" class="link1">Read More</a><--> </div>
        <div class="cols pad_left1">
          <figure class="pad_bot2 pad_top1"><img src="images/img6.jpg" alt=""></figure>
          <p class="pad_bot2"> <span class="font1 color2">Cardamom</span><br>
            <em>Cardamom is a spice made from the seed pods of various plants in the ginger family. Cardamom pods are spindle-shaped and have a triangular cross-section</em><br>
          </p>
          <!--<a href="#" class="link1">Read More</a><--> </div>
        <div class="cols pad_left1">
          <figure class="pad_bot2 pad_top1"><img src="images/img7.jpg" alt=""></figure>
          <p class="pad_bot2"> <span class="font1 color2">Coffee beans</span><br>
            <em>A coffee bean is a seed of the Coffea plant and the source for coffee.</em><br>
          </p>
          <!--<a href="#" class="link1">Read More</a><--> </div>
      </div>
    </article>
    <!-- / content -->
  </div>
</div>
<div class="main">
  <!-- footer -->
  <footer>
    <div class="wrapper">
      <section class="col2">
        <div class="wrapper">
          <section class="col4">
           <!-- <h3>Follow Us </h3>
            <ul id="icons">
              <li><a href="#"><img src="images/icon1.jpg" alt=""><span>Facebook</span></a></li>
              <li><a href="#"><img src="images/icon2.jpg" alt=""><span>Twitter</span></a></li>
              <li><a href="#"><img src="images/icon3.jpg" alt=""><span>Linked In</span></a></li>
            </ul>-->
          </section>
          <!--<section class="col4 pad_left1">
            <h3>Why Us </h3>
            <ul id="why_us">
              <li><a href="#">Sed perspiciatis unde </a></li>
              <li><a href="#">Omnis natus error</a></li>
              <li><a href="#">Voluptatem accusantium </a></li>
            </ul>
          </section><-->
        </div>
        <!--<div id="footer_link">Copyright &copy; <a href="#">Domain Name</a> All Rights Reserved<br>
          Design by <a target="_blank" href="http://www.templatemonster.com/">TemplateMonster.com</a></div><-->
      </section>
      <!--<section class="col3 pad_left2">
        <h3>Email Us</h3>
        <form id="ContactForm" action="#">
          <div>
            <div class="wrapper"> <span>Your Name:</span>
              <div class="bg">
                <input type="text" class="input">
              </div>
            </div>
            <div class="wrapper"> <span>Your E-mail:</span>
              <div class="bg">
                <input type="text" class="input">
              </div>
            </div>
            <div class="textarea_box"> <span>Your Message:</span>
              <div class="bg2">
                <textarea name="textarea" cols="1" rows="1"></textarea>
              </div>
            </div>
            <a href="#">Submit</a> </div>
        </form>
      </section><-->
    </div>
    <!-- {%FOOTER_LINK} -->
  </footer>
  <!-- / footer -->
</div>
</body>
</html>