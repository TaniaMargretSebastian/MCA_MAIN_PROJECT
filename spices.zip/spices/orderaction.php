<?php
include 'connection.php';
session_start();
error_reporting(0);
$uid = $_SESSION['id'];
if($_SESSION['id']==""){
  header('location:login.php');
}
$cartid = $_GET['cid'];
$pid=$_GET['pid'];
$price = $_GET['price'];
$pname=$_GET['pname'];
$qua = $_GET['qua'];
$da=date('d-m-y');
//$order="INSERT INTO `order_tbl`(`userid`, `cartid`, `price`, `status`,`date`) VALUES ('$uid', '$cartid', '$price','placed','$da')";

//$n=mysqli_query($con,"update tbl_cart set orderid='$inv'");
//$or1=mysqli_query($con,$order);
//$sqlls = "UPDATE tbl_cart SET status='1' where id=$cartid";
//mysqli_query($con,$sqlls);
//$query="SELECT * FROM product where pid='$pid'";
//$result=mysqli_query($con,$query);
//while($row=mysqli_fetch_array($result))
//{
//$quan=$row['qty'];
//$qwer=0;

//$qwer=$quan-$qua;

//echo $qwer;
//$query2=mysqli_query($con,"UPDATE product SET qty='$qwer' where pid='$pid'");
//}
//$a=mysqli_query($con,"select max(id) from order_tbl");
//$v=mysqli_fetch_array($a);
//$inv=$v[0];
//$n=mysqli_query($con,"update tbl_cart set orderid='$inv' where id='$cartid'");


// $orid = mysqli_insert_id($con);
// $qq = mysqli_query($con,"UPDATE `tbl_cart` SET status=1, orderid ='$orid' WHERE status = 0 and userid = '$uid' ");

$sq==mysqli_query($con,"delete from tbl_cart");
echo"<script>window.location='final.php';</script>";

?>