<?php 
include 'connection.php';
session_start();
$uid=$_SESSION['id'];
$cartid = $_GET['uu'];
$price = $_GET['id'];


$sql="INSERT INTO `tbl_payment`( `login_id`, `cartid`, `amount`, `status`) VALUES ('$uid','$cartid','$price','success')";
mysqli_query($con,$sql);

  
  echo "<script>window.location='paysu/index.html';</script>"

?>